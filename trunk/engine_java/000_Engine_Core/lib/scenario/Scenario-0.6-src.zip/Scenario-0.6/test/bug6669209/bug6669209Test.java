/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6669209;

import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.SGAbstractShape.Mode;
import com.sun.scenario.scenegraph.SGGroup;
import com.sun.scenario.scenegraph.SGRenderCache;
import com.sun.scenario.scenegraph.SGShape;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.concurrent.CountDownLatch;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.junit.Assert;
import org.junit.Test;

/*
 * Regression test for
 * 6669209 - SGRenderCache needs to be invalidated for changes in child visual state
 * Also tests both change bounds and changing a rendering attribute.
 */
public class bug6669209Test {

    @Test(timeout=1000*3)
    public void testVisualStateChange() throws Exception {
        final JFrame f[] = new JFrame[1];
        final CountDownJSGPanel p[] = new CountDownJSGPanel[1];
        final SGShape s[] = new SGShape[1];
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                f[0] = new JFrame();
                p[0] = new CountDownJSGPanel();
                s[0] = makeRectShape(0, 0, 100, 100, Color.yellow);
                SGRenderCache rc = new SGRenderCache();
                rc.setChild(s[0]);
                p[0].setScene(rc);
                f[0].add(p[0]);
                f[0].pack();
                f[0].setVisible(true);
            }
        });
        p[0].await();
        p[0].reset();
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                s[0].setFillPaint(Color.red);
            }
        });
        p[0].await();
        final BufferedImage bimg =
            new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                renderTo(p[0], bimg);
                f[0].setVisible(false);
                f[0].dispose();
            }
        });
        Assert.assertEquals("render cache not updated for color change",
                            Color.red.getRGB(),
                            bimg.getRGB(50, 50));
    }

    @Test(timeout=1000*3)
    public void testBoundsChange() throws Exception {
        final JFrame f[] = new JFrame[1];
        final CountDownJSGPanel p[] = new CountDownJSGPanel[1];
        final SGShape s[] = new SGShape[1];
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                f[0] = new JFrame();
                p[0] = new CountDownJSGPanel();
                SGGroup g = new SGGroup();
                g.add(makeRectShape(0, 0, 100, 100, Color.red));
                s[0] = makeRectShape(0, 0, 100, 100, Color.yellow);
                g.add(s[0]);
                SGRenderCache rc = new SGRenderCache();
                rc.setChild(g);
                p[0].setScene(rc);
                f[0].add(p[0]);
                f[0].pack();
                f[0].setVisible(true);
            }
        });
        p[0].await();
        p[0].reset();
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                s[0].setShape(new Rectangle(20, 20, 60, 60));
            }
        });
        p[0].await();
        final BufferedImage bimg =
            new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
                renderTo(p[0], bimg);
                f[0].setVisible(false);
                f[0].dispose();
            }
        });
        Assert.assertEquals("render cache not updated for child reshape",
                            Color.red.getRGB(),
                            bimg.getRGB(10, 10));
    }

    public static class CountDownJSGPanel extends JSGPanel {
        CountDownLatch nextPaintLatch;
        
        public CountDownJSGPanel() {
            reset();
        }

        public void reset() {
            nextPaintLatch = new CountDownLatch(1);
        }

        public void await() throws InterruptedException {
            nextPaintLatch.await();
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            nextPaintLatch.countDown();
        }
    }

    public SGShape makeRectShape(int x, int y, int w, int h, Color c) {
        SGShape r = new SGShape();
        r.setShape(new Rectangle(x, y, w, h));
        r.setFillPaint(c);
        r.setMode(Mode.FILL);
        return r;
    }

    public void renderTo(CountDownJSGPanel p, BufferedImage bimg) {
        Graphics g = bimg.getGraphics();
        g.setClip(new Rectangle(0, 0, bimg.getWidth(), bimg.getHeight()));
        p.paintComponent(g);
        g.dispose();
    }
}
