/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6664092;

import com.sun.scenario.animation.BeanProperty;
import com.sun.scenario.animation.Clip;
import com.sun.scenario.animation.Property;
import com.sun.scenario.animation.TimingTarget;
import com.sun.scenario.animation.TimingTargetAdapter;
import org.junit.Assert;
import org.junit.Test;

/**
 * Regression test for
 * 6664092 - Clip.repeatCount of 0.5 fails
 */
public class bug6664092Test {
    TimingTarget tt = new TimingTargetAdapter();
    Property prop = new BeanProperty(this, "foo");

    @Test(timeout=1000 * 5)
    public void test() {
        test(Clip.INDEFINITE, false);
        test(-0.5f, true);
        test(0.0f, false);
        test(0.1f, false);
        test(0.5f, false);
        test(0.9f, false);
        test(1.0f, false);
        test(1.5f, false);
        test(2.0f, false);
    }

    public void test(float repeatCount, boolean expectException) {
        // First test initializing to repeatCount [then setting to 1.0]
        test(repeatCount, 1.0f, expectException);
        // Next test initializing to 1.0, then setting to repeatCount
        test(1.0f, repeatCount, expectException);
    }
    
    public void test(float initCount, float setCount, boolean expectException) {
        try {
            Clip c = Clip.create(1000, initCount, tt);
            c.setRepeatCount(setCount);
            noException(expectException);
        } catch (Exception e) {
            gotException(expectException);
        }
        try {
            Clip c = Clip.create(1000, initCount, this, "foo", 1);
            c.setRepeatCount(setCount);
            noException(expectException);
        } catch (Exception e) {
            gotException(expectException);
        }
        try {
            Clip c = Clip.create(1000, initCount, prop, 1);
            c.setRepeatCount(setCount);
            noException(expectException);
        } catch (Exception e) {
            gotException(expectException);
        }
    }

    public int getFoo() {
        return 0;
    }

    public void setFoo(int foo) {
    }

    static void gotException(boolean wasExpected) {
        if (!wasExpected) {
            Assert.fail("Exception thrown for valid repeat count");
        }
    }

    static void noException(boolean wasExpected) {
        if (wasExpected) {
            Assert.fail("Exception not thrown for invalid repeat count");
        }
    }
}
