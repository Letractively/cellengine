/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6662864;

import com.sun.scenario.effect.PhongLighting;
import com.sun.scenario.effect.Shadow;
import com.sun.scenario.effect.Source;
import com.sun.scenario.effect.light.DistantLight;
import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.fx.FXShape;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*
 * Regression test for
 * 6662864 - Setting a radius ... doesn't update the rendering
 */
public class bug6662864Test {
    //to be accessed from the EDT only
    private JFrame frame; 
    private JSGPanel panel;
    @Before 
    public void setUp() throws Exception {
        invokeAndWait(new Callable<Void>() {
            public Void call() throws Exception {
                frame = new JFrame();
                return null;
            }
        });
    }
    @After
    public void tearDown() throws Exception {
        invokeAndWait(new Callable<Void>() {
            public Void call() throws Exception {
                frame.dispose();
                return null;
            }
        });
    }
    
    @Test(timeout=1000 * 10)
    public void test() throws Exception {
        final CountDownLatch firstPaintLatch = new CountDownLatch(1);
        final Shadow bump = new Shadow(5f, Color.WHITE);

        invokeAndWait(
            new Callable<Void>() {
                public Void call() throws Exception {
                    Source source = new Source(true);
                    PhongLighting phong = new PhongLighting(new DistantLight(45, 15, Color.WHITE), bump, source);
                    
                    final FXShape shape = new FXShape();
                    shape.setShape(new Ellipse2D.Float(0, 0, 100, 100));
                    shape.setFillPaint(Color.RED);
                    shape.setEffect(phong);
                    
                    panel = new JSGPanel() {
                        @Override
                        public void paintComponent(Graphics g) {
                            super.paintComponent(g);
                            firstPaintLatch.countDown();
                        }
                    };
                    panel.setScene(shape);
                    panel.setBackground(Color.BLACK);
                    frame.add(panel);
                    frame.pack();
                    frame.setVisible(true);
                    return null;
                }
            });
        firstPaintLatch.await();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {}
        BufferedImage capture1 = capture(panel);
        invokeAndWait(
            new Callable<Void>() {
                public Void call() throws Exception {
                    bump.setRadius(20f);
                    return null;
                }
            });
        try {
            Thread.sleep(3000);
        } catch (Exception e) {}
        BufferedImage capture2 = capture(panel);
        assertFalse(compare(capture1, capture2));
    }
    
    static BufferedImage capture(JComponent test) {
        BufferedImage capture = null;
	try {
            Robot robot = new Robot();
            Point pt1 = test.getLocationOnScreen();
            Rectangle rect = new Rectangle(pt1.x, pt1.y, test.getWidth(), test.getHeight());
            capture = robot.createScreenCapture(rect);
        } catch (Exception e) {
            throw new RuntimeException("Problems creating Robot");
        }
        return capture;
    }
    
    static boolean compare(BufferedImage img1, BufferedImage img2) {
        boolean same = true;
        for (int y = 0; y < img1.getHeight(); y++) {
            for (int x = 0; x < img1.getWidth(); x++) {
                if (img1.getRGB(x, y) != img2.getRGB(x, y)) {
                    same = false;
                    break;
                }
            }
        }
        return same;
    }
    
    static <T> T invokeAndWait(Callable<T> callable) throws Exception {
        try {
            FutureTask<T> future = new FutureTask<T>(callable);
            SwingUtilities.invokeLater(future);
            return future.get();
        } catch (ExecutionException e) {
            throw (Exception) e.getCause();
        }
    }
};
