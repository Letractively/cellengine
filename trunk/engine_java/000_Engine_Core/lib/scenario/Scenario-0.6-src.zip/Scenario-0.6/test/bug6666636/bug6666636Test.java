/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6666636;

import com.sun.scenario.scenegraph.SGAbstractShape;
import com.sun.scenario.scenegraph.SGAbstractShape.Mode;
import com.sun.scenario.scenegraph.SGShape;
import com.sun.scenario.scenegraph.SGText;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Regression test for
 * 6666636 SGText with Mode=STROKE still fills the text and then draws the text
 * This test also tests all Modes and both SGText and SGShape for conformance.
 */
public class bug6666636Test {
    static final int W = 50;
    static final int H = 50;

    BufferedImage bimg =
        new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);

    @Test(timeout = 1000 * 10)
    public void testShape() {
        SGShape s = new SGShape();
        s.setShape(new Rectangle(10, 10, 30, 30));
        test(s);
    }
    
    @Test(timeout = 1000 * 10)
    public void testText() {
        SGText t = new SGText();
        t.setText("A");
        t.setFont(new Font("Serif", Font.BOLD, H*3/4));
        t.setLocation(new Point(10, 40));
        test(t);
    }

    public void test(SGAbstractShape leaf) {
        check(leaf, Mode.FILL);
        check(leaf, Mode.STROKE_FILL);
        check(leaf, Mode.STROKE);
    }

    public void check(SGAbstractShape leaf, Mode m) {
        leaf.setMode(m);
        leaf.setFillPaint(Color.red);
        leaf.setDrawPaint(Color.green);
        leaf.setDrawStroke(new BasicStroke(4f));
        Graphics2D g2d = bimg.createGraphics();
        g2d.setColor(Color.white);
        g2d.fillRect(0, 0, W, H);
        leaf.paint(g2d);
        g2d.dispose();
        checkImage(m);
    }
    
    public void checkImage(Mode m) {
        int redrgb = Color.red.getRGB();
        int greenrgb = Color.green.getRGB();
        boolean foundred = false;
        boolean foundgreen = false;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                int rgb = bimg.getRGB(x, y);
                if (rgb == redrgb) foundred = true;
                if (rgb == greenrgb) foundgreen = true;
            }
        }
        if (foundred == (m == Mode.STROKE)) {
            String result = (foundred ? "found" : "missing");
            fail("fill color "+result+" during "+m+" operation");
        }
        if (foundgreen == (m == Mode.FILL)) {
            String result = (foundgreen ? "found" : "missing");
            fail("draw color "+result+" during "+m+" operation");
        }
    }
}
