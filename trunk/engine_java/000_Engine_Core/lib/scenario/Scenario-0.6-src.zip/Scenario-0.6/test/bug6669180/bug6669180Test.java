/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6669180;

import com.sun.scenario.effect.Reflection;
import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.SGEffect;
import com.sun.scenario.scenegraph.SGShape;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*
 * Regression test for
 * 6669180 Some effects don't repaint properly when child nodes change visual state
 */
public class bug6669180Test {
    //to be accessed from the EDT only
    private JFrame frame; 
    private JSGPanel panel;
    @Before 
    public void setUp() throws Exception {
        invokeAndWait(new Callable<Void>() {
            public Void call() throws Exception {
                frame = new JFrame();
                return null;
            }
        });
    }
    @After
    public void tearDown() throws Exception {
        invokeAndWait(new Callable<Void>() {
            public Void call() throws Exception {
                frame.dispose();
                return null;
            }
        });
    }
    
    @Test(timeout=1000 * 10)
    public void test() throws Exception {
        final CountDownLatch firstPaintLatch = new CountDownLatch(1);
        final SGShape shape = new SGShape();

        invokeAndWait(
            new Callable<Void>() {
                public Void call() throws Exception {
                    final Reflection reflect = new Reflection();
                    reflect.setFraction(1f);
                    reflect.setTopOpacity(1f);
                    reflect.setBottomOpacity(1f);
                    
                    shape.setShape(new Rectangle(20, 20, 100, 100));
                    shape.setFillPaint(Color.RED);
                    
                    SGEffect effect = new SGEffect();
                    effect.setEffect(reflect);
                    effect.setChild(shape);
                    
                    panel = new JSGPanel() {
                        @Override
                        public void paintComponent(Graphics g) {
                            super.paintComponent(g);
                            firstPaintLatch.countDown();
                        }
                    };
                    panel.setScene(effect);
                    panel.setBackground(Color.BLACK);
                    panel.setPreferredSize(new Dimension(300, 300));
                    frame.add(panel);
                    frame.pack();
                    frame.setVisible(true);
                    return null;
                }
            });
        firstPaintLatch.await();
        try {
            Thread.sleep(2000);
        } catch (Exception e) {}
        invokeAndWait(
            new Callable<Void>() {
                public Void call() throws Exception {
                    shape.setFillPaint(Color.BLUE);
                    return null;
                }
            });
        try {
            Thread.sleep(2000);
        } catch (Exception e) {}
        BufferedImage capture = capture(panel);
        assertTrue(capture.getRGB(50, 150) == 0xff0000ff);
    }
    
    static BufferedImage capture(JComponent test) {
        BufferedImage capture = null;
	try {
            Robot robot = new Robot();
            Point pt1 = test.getLocationOnScreen();
            Rectangle rect = new Rectangle(pt1.x, pt1.y, test.getWidth(), test.getHeight());
            capture = robot.createScreenCapture(rect);
        } catch (Exception e) {
            throw new RuntimeException("Problems creating Robot");
        }
        return capture;
    }
    
    static <T> T invokeAndWait(Callable<T> callable) throws Exception {
        try {
            FutureTask<T> future = new FutureTask<T>(callable);
            SwingUtilities.invokeLater(future);
            return future.get();
        } catch (ExecutionException e) {
            throw (Exception) e.getCause();
        }
    }
};
