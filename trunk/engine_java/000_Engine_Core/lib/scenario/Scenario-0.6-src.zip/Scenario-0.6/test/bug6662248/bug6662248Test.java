/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6662248;

import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.SGAbstractShape.Mode;
import com.sun.scenario.scenegraph.SGGroup;
import com.sun.scenario.scenegraph.SGShape;
import com.sun.scenario.scenegraph.SGTransform;
import com.sun.scenario.scenegraph.SGTransform.Translate;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import org.junit.Assert;
import org.junit.Test;

/*
 * Regression test for
 * 6662248 - Repainting issue with a stroke width of zero.
 */
public class bug6662248Test {
    public static final int RECTW = 20;
    public static final int RECTH = 20;
    public static final int PANELW = 150;
    public static final int PANELH = 150;

    private Translate trans;
    private SGShape rect;
    JSGPanel panel;

    @Test(timeout=1000*3)
    public void testAuto() {
        setupScene();
        setupFrame();
        testBounds();
    }

    // Not really a test since it doesn't check anything,
    // just for visual verification...
//    @Test(timeout=1000*20)
    public void testManual() {
        setupScene();
        JFrame f = setupFrame();
        f.setVisible(true);
        int pdim = Math.min(PANELW, PANELH);
        int rdim = Math.max(RECTW, RECTH);
        try {Thread.sleep(1000);} catch (InterruptedException e) {}
        for(int i = pdim-rdim; i >= 0; i -= 5) {
            trans.setTranslation(i, i);
            try {Thread.sleep(100);} catch (InterruptedException e) {}
        }
    }

    private void setupScene() {
        panel = new JSGPanel();
        SGGroup group = new SGGroup();
        SGShape bgrect = new SGShape();
        bgrect.setShape(new Rectangle(0, 0, PANELW, PANELH));
        bgrect.setMode(Mode.FILL);
        bgrect.setFillPaint(Color.white);
        group.add(bgrect);
        rect = new SGShape();
        rect.setMode(Mode.STROKE_FILL);
        rect.setDrawStroke(new BasicStroke(0));
        rect.setFillPaint(Color.RED);
        rect.setDrawPaint(Color.BLACK);
        rect.setShape(new Rectangle(0, 0, RECTW, RECTH));
        trans = SGTransform.createTranslation(10,10,rect);
        group.add(trans);
        panel.setScene(group);
    }

    public JFrame setupFrame() {
        JFrame f = new JFrame("Test");
        f.add(panel);
        f.pack();
        return f;
    }

    public static void main(String[] args) {
        new bug6662248Test().testAuto();
        new bug6662248Test().testManual();
    }

    private void testBounds() {
        BufferedImage bimg =
            new BufferedImage(PANELW, PANELH, BufferedImage.TYPE_INT_RGB);
        int pdim = Math.min(PANELW, PANELH);
        int rdim = Math.max(RECTW, RECTH);
        int count = 0;
        testRenderBounds(bimg);
        for(int i = pdim-rdim; i >= 0; i -= 5) {
            trans.setTranslation(i, i);
            testRenderBounds(bimg);
            count++;
        }
        if (count < 10) {
            Assert.fail("failed to run test required number of iterations");
        }
    }

    private void testRenderBounds(BufferedImage bimg) {
        Graphics g = bimg.getGraphics();
        panel.paint(g);
        g.dispose();
        int whitergb = Color.white.getRGB();
        Rectangle rb = rect.getBounds(trans.createAffineTransform()).getBounds();
        boolean foundone = false;
        for (int y = 0; y < bimg.getHeight(); y++) {
            for (int x = 0; x < bimg.getWidth(); x++) {
                if (bimg.getRGB(x, y) != whitergb) {
                    foundone = true;
                    if (!rb.contains(x, y)) {
                        System.err.println("rect bounds = "+rb);
                        System.err.println("pixel at "+x+", "+y+" == "+
                                           Integer.toHexString(bimg.getRGB(x, y)));
                        Assert.fail("non-white pixel outside of rect bounds");
                    }
                }
            }
        }
        if (!foundone) {
            Assert.fail("did not find any non-white pixels");
        }
    }
}
