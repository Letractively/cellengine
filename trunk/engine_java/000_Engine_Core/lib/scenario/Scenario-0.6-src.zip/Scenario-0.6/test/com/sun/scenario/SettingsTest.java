/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sun.scenario;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.InvocationTargetException;
import javax.swing.SwingUtilities;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author bchristi
 */
public class SettingsTest {

    public SettingsTest() {
    }

    /*
    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }
     */

    /**
     * Test of set method, of class Settings.
     */
    @Test
    public void set() {
        System.out.println("set");
        String key = "SettingsTest.set";
        String value = "value";
        Settings.set(key, value);
        assertEquals(Settings.get(key), value);
    }

    /**
     * Test that a null key throws an exception
     */
    @Test
    public void setNullKey() {
        System.out.println("setNullKey");
        boolean threwIAE = false;
        String key = null;
        String value = "value";

        try {
            Settings.set(key, value);
        } catch (IllegalArgumentException e) {
            threwIAE = true;
        }
        assertTrue(threwIAE);
    }

    /**
     * Test set() method, setting value to null and picking up the value
     * from the System Properties.
     */
    @Test
    public void setNullSysProp() {
        System.out.println("setNullSysProp");
        String key = "SettingsTest.setNullSysProp";
        String value = "value";
        String sysPropValue = "sysPropValue";

        System.setProperty(key, sysPropValue);

        Settings.set(key, value);
        Settings.set(key, null);
        String result = Settings.get(key);

        assertEquals(result, sysPropValue);
    }

    /**
     * Test of get method, of class Settings.
     */
    @Test
    public void get() {
        System.out.println("get");
        String key = "Settings.get";
        String value = "value";

        String sysPropValue = "sysPropValue";
        System.setProperty(key, sysPropValue);

        Settings.set(key, value);

        String result = Settings.get(key);
        assertEquals(result, value);
    }

    /**
     * Test get when value should come from system property
     */
    @Test
    public void getSysProp() {
        System.out.println("getSysProp");
        String key = "Settings.getSysProp";
        String sysPropValue = "sysPropValue";
        System.setProperty(key, sysPropValue);

        String result = Settings.get(key);
        assertEquals(result, sysPropValue);
    }

    /**
     * Test getBoolean where the value is true
     */
    @Test
    public void getBooleanTrue() {
        System.out.println("getBooleanTrue");
        String key = "Settings.getBooleanTrue";
        Settings.set(key, "true");
        boolean result = Settings.getBoolean(key);
        assertEquals(result, true);
    }

    /**
     * Test getBoolean where the value was set to "false"
     */
    @Test
    public void getBooleanFalse() {
        System.out.println("getBooleanFalse");
        String key = "Settings.getBooleanFalse";
        Settings.set(key, "false");
        boolean result = Settings.getBoolean(key);
        assertEquals(result, false);
    }

    /*
     * Test getBoolean for an unset key
     */
    @Test
    public void getBooleanUnset() {
        System.out.println("getBooleanUnset");
        String key = "Settings.getBooleanUnset";
        boolean result = Settings.getBoolean(key);
        assertEquals(result, false);
    }

    /*
     * Test getBoolean() for a bogus value
     */
    @Test
    public void getBooleanMisc() {
        System.out.println("getBooleanMisc");
        String key = "Settings.getBooleanMisc";
        Settings.set(key, "bogus");
        boolean result = Settings.getBoolean(key);
        assertEquals(result, false);
    }

    private static class TestPCL implements PropertyChangeListener {

        PropertyChangeEvent event = null;

        public void propertyChange(PropertyChangeEvent e) {
            event = e;
        }

        public PropertyChangeEvent getPCE() {
            return event;
        }
    }

    /**
     * Test of addPropertyChangeListener method, of class Settings.
     */
    @Test
    public void addPCL() throws InterruptedException, InvocationTargetException {
        System.out.println("addPCL");
        String key = "Settings.addPCL";
        String value = "Settings.addPCL.value";
        TestPCL testpcl = new TestPCL();
        Settings.addPropertyChangeListener(key, testpcl);
        // do change
        Settings.set(key, value);
        // flush EDT
        SwingUtilities.invokeAndWait(new Runnable() {

            public void run() {
            }
        });
        PropertyChangeEvent event = testpcl.getPCE();
        Settings.removePropertyChangeListener(testpcl);
        assertNotNull(event);
        assertEquals(value, event.getNewValue());
    }

    /**
     * Test adding a PCL and that the values in the event are correctly
     * picked up from the System Properties.
     */
    @Test
    public void addPCLSysProp() throws InterruptedException, InvocationTargetException {
        System.out.println("addPCLSysProp");
        String key = "Settings.addPCLSysProp";
        String value = "Settings.addPCLSysProp.value";
        String sysPropValue = "Settings.addPCLSysProp.sysPropValue";

        Settings.set(key, value);
        System.setProperty(key, sysPropValue);
        
        TestPCL testpcl = new TestPCL();
        Settings.addPropertyChangeListener(key, testpcl);
        // set to null, therefore get value from sys prop
        Settings.set(key, null);
        // flush EDT
        SwingUtilities.invokeAndWait(new Runnable() {
            public void run() {
            }
        });
        
        PropertyChangeEvent event = testpcl.getPCE();
        Settings.removePropertyChangeListener(testpcl);
        assertNotNull(event);
        assertEquals(sysPropValue, event.getNewValue());

    }
}
