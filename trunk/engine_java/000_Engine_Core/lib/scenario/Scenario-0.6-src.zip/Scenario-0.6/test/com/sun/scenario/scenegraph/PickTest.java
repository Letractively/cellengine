/*
 * Copyright 2007 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.scenegraph;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.util.List;
import junit.framework.*;


/**
 *
 * @author Hans Muller
 */
public class PickTest extends TestCase {
    
    public PickTest(String testName) {
        super(testName);
    }

    private void checkNodes(List<SGNode> nodes, String ids) {
        StringBuffer sb = new StringBuffer();
        for(SGNode node : nodes) {
            if (sb.length() > 0) {
                sb.append(" ");
            }
            sb.append(node.getID());
        }
        assertEquals(ids, sb.toString());
    }

    private SGShape createR10(String id) {
        SGShape shape = new SGShape();
        shape.setShape(new Rectangle(0, 0, 10, 10));
        shape.setID(id);
        return shape;
    }

    private SGGroup createGroup(String id) {
        SGGroup group = new SGGroup(); 
        group.setID(id);
        return group;
    }
    
    private SGNode createGraph1() {
        SGGroup group = createGroup("G");
        for(int i = 0; i < 3; i++) {
            group.add(i, createR10("L" + i));
        }
        return group;
    }

    public void testPick1() {
        SGNode root = createGraph1();
        checkNodes(root.pick(new Point(5, 5)), "L2 L1 L0 G");
        checkNodes(root.pick(new Point(11, 11)), "");
    }

    private SGNode createGraph2() {
        SGGroup root = new SGGroup();
        root.setID("R");
        SGGroup g1 = createGroup("G1");
        SGGroup g2 = createGroup("G2");
        SGGroup g3 = createGroup("G3");
        SGGroup g4 = createGroup("G4");
        root.add(g1);
        root.add(g2);
        root.add(g3);
        g1.add(createR10("L1"));
        g3.add(g4);
        g3.add(createR10("L4"));
        g3.add(createR10("L5"));
        g4.add(createR10("L2"));
        g4.add(createR10("L3"));
        return root;
    }

    public void testPick2() {
        SGNode root = createGraph2();
        checkNodes(root.pick(new Point(5, 5)), "L5 L4 L3 L2 G4 G3 L1 G1 R");
        checkNodes(root.pick(new Point(11, 11)), "");
    }

    private SGNode createGraph3() {
        SGGroup root = new SGGroup();
        root.setID("R");
        SGGroup g1 = createGroup("G1");
        SGGroup g2 = createGroup("G2");
        SGGroup g3 = createGroup("G3");
        SGGroup g4 = createGroup("G4");
        root.add(g1);
        root.add(g2);
        root.add(g3);
        g1.add(createR10("L1"));
        SGTransform f4 = SGTransform.createTranslation(15.0, 15.0, g4);
        f4.setID("F4");
        g3.add(f4);
        g3.add(createR10("L4"));
        g3.add(createR10("L5"));
        g4.add(createR10("L2"));
        g4.add(createR10("L3"));
        return root;
    }

    public void testPick3() {
        SGNode root = createGraph3();
        checkNodes(root.pick(new Point(5, 5)), "L5 L4 G3 L1 G1 R");
        checkNodes(root.pick(new Point(11, 11)), "");
        checkNodes(root.pick(new Point(16, 16)), "L3 L2 G4 F4 G3 R");
        root.setVisible(false);
        checkNodes(root.pick(new Point(5, 5)), "");
        root.setVisible(true);
        checkNodes(root.pick(new Point(5, 5)), "L5 L4 G3 L1 G1 R");
    }


    private SGNode createGraph4() {
        SGGroup root = new SGGroup();
        root.setID("R");
        root.add(createR10("L1"));
        return root;
    }

    public void testPick4() {
        SGNode root = createGraph4();
        checkNodes(root.pick(new Point(5, 5)), "L1 R");
        checkNodes(root.pick(new Point(11, 11)), "");
        SGTransform xform = SGTransform.createScale(2.0, 2.0, root);
        xform.setID("XF");
        checkNodes(xform.pick(new Point(11, 11)), "L1 R XF");
    }

}
