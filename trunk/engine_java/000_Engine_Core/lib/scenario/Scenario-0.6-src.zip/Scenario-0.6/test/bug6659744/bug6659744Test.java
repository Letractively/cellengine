/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6659744;

import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.SGAbstractShape.Mode;
import com.sun.scenario.scenegraph.SGShape;
import com.sun.scenario.scenegraph.SGTransform;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import org.junit.Test;

/*
 * Regression test for
 * 6659744 - Setting Same Shear Factor to Shear Transform causes
 *           Internal Error to be thrown
 */
public class bug6659744Test {
    @Test(timeout=1000 * 3)
    public void testAA() {
        test(true);
    }

    @Test(timeout=1000 * 3)
    public void testNonAA() {
        test(false);
    }

    public void test(boolean aa) {
        JSGPanel p = new JSGPanel();
        p.setSize(20, 20);
        SGShape s = new SGShape();
        s.setShape(new Rectangle(0, 0, 10, 10));
        s.setAntialiasingHint(aa
                              ? RenderingHints.VALUE_ANTIALIAS_ON
                              : RenderingHints.VALUE_ANTIALIAS_OFF);
        s.setMode(Mode.STROKE_FILL);
        SGTransform tx = SGTransform.createShear(1f, 1f, s);
        p.setScene(tx);
        BufferedImage bimg =
            new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
        p.paint(bimg.getGraphics());
    }
}
