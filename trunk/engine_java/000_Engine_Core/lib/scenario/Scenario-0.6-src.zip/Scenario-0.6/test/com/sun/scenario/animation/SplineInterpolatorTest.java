package com.sun.scenario.animation;

import java.text.NumberFormat;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Verifies that the Interpolator returned by Interpolators.getSplineInstance()
 * produces values that are (reasonably) consistent with the SMIL
 * specification.  The reference values are derived from the table after
 * Figure 7 on the following page:
 *   http://www.w3.org/TR/SMIL/animation.html#animationNS-OverviewSpline
 * 
 * @author David C. Browne
 * @author Chris Campbell
 */
public class SplineInterpolatorTest {

    /** Allow for some deviation between reference/actual results */
    private static final float TOL = 0.12f;
    
    private static final NumberFormat nf = NumberFormat.getInstance();
    static {
        nf.setMinimumFractionDigits(3);
        nf.setMaximumFractionDigits(3);
    }
    
    public SplineInterpolatorTest() {
    }

    private static float scaleFrom10To20(float normalizedVal) {
        return 10f + (normalizedVal * 10f);
    }
    
    private void compare(float x1, float y1, float x2, float y2,
                         float... smilData)
    {
        Interpolator ipol = Interpolators.getSplineInstance(x1, y1, x2, y2);
        
        System.out.println("\nControl points: (" + x1 + ", " + y1 +
                "), (" + x2 + ", " + y2 + ")");
        System.out.println("x\tsecond\tSMIL\tSG");
        float increment = 1f / (smilData.length - 1);
        for (int i = 0; i < smilData.length; i++) {
            float x = i * increment;
            float expected = smilData[i];
            float actual = scaleFrom10To20(ipol.interpolate(x));
            System.out.println(x + "\t" + i + "\t" + nf.format(expected) +
                    "\t" + nf.format(actual));
            assertTrue(Math.abs(expected - actual) < TOL);
        }
    }
    
    @Test
    public void compareToReference() {
        compare(0f, 0f, 1f, 1f,
                10f, 12.5f, 15f, 17.5f, 20f);
        compare(0.5f, 0f, 0.5f, 1f,
                10f, 11f, 15f, 19f, 20f);
        compare(0f, 0.75f, 0.25f, 1f,
                10f, 18f, 19.3f, 19.8f, 20f);
        compare(1f, 0f, 0.25f, 0.25f,
                10f, 10.1f, 10.6f, 16.9f, 20f);
    }
}
