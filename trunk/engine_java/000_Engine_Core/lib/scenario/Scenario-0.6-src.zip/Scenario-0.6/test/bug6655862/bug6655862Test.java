/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package bug6655862;

import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.SGShape;
import org.junit.Assert;
import org.junit.Test;

/*
 * Regression test for
 * 6655862 - Calling JSGPanel.setScene() twice throws an incorrect Exception
 * Also tests setting the scene from another Panel.
 */
public class bug6655862Test {
    @Test(timeout=1000 * 5)
    public void testSetSceneTwice() {
        SGShape shape = new SGShape();

        JSGPanel panel = new JSGPanel();
        panel.setScene(shape);
        Assert.assertEquals(panel.getScene(), shape);
        for (int i = 0; i < 10; i++) {
            panel.setScene(shape);
            Assert.assertEquals(panel.getScene(), shape);
        }
    }

    @Test(timeout=1000 * 5)
    public void testSetSceneFromOther() {
        SGShape shape = new SGShape();

        JSGPanel panel1 = new JSGPanel();
        JSGPanel panel2 = new JSGPanel();
        panel1.setScene(shape);
        Assert.assertEquals(panel1.getScene(), shape);
        for (int i = 0; i < 10; i++) {
            panel2.setScene(shape);
            Assert.assertNull(panel1.getScene());
            Assert.assertEquals(panel2.getScene(), shape);
            panel1.setScene(shape);
            Assert.assertEquals(panel1.getScene(), shape);
            Assert.assertNull(panel2.getScene());
        }
    }

    public static void main (String args[]) {
        new bug6655862Test().testSetSceneTwice();
        new bug6655862Test().testSetSceneFromOther();
    }
}
		