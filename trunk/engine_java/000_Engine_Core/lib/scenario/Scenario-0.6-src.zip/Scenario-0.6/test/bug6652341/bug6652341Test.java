/*
 * Copyright 2007 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Regression test for
 * 6652341 - Calling requestFocus() on SGComponent node at the time of creation 
 *           throws Exception
 */
package bug6652341;

import java.awt.Rectangle;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.sun.scenario.scenegraph.JSGPanel;
import com.sun.scenario.scenegraph.SGGroup;
import com.sun.scenario.scenegraph.SGNode;
import com.sun.scenario.scenegraph.SGShape;
import com.sun.scenario.scenegraph.event.SGFocusListener;
import com.sun.scenario.scenegraph.event.SGKeyListener;

public class bug6652341Test {
    private volatile CountDownLatch latch;
    
    //to be accessed from the EDT only
    private JFrame frame; 
    @Before 
    public void setUp() throws Exception {
        latch = new CountDownLatch(1);
        invokeAndWait(new Callable<Void>() {
            public Void call() throws Exception {
                frame = new JFrame();
                return null;
            }
        });
    }
    @After
    public void tearDown() throws Exception {
        latch = null;
        invokeAndWait(new Callable<Void>() {
            public Void call() throws Exception {
                frame.dispose();
                return null;
            }
        });
    }
    
    /*
     * Tests  
     * - SGNode does not throw exception on requestFocus if not
     * connected to JSGPanel.
     * - SGNode receives focus when added to JSGPanel
     */
    @Test(timeout=1000 * 5)
    public void test() throws Exception {
        invokeAndWait(
            new Callable<Void>() {
                public Void call() throws Exception {
                    final SGShape shape1 = new SGShape();
                    final SGShape shape2 = new SGShape();
                    SGKeyListener keyListener = new SGKeyListener() {
                        public void keyPressed(KeyEvent e, SGNode node) {
                        }
                        public void keyReleased(KeyEvent e, SGNode node) {
                        }
                        public void keyTyped(KeyEvent e, SGNode node) {
                        }
                    };
                    SGFocusListener focusListener = new SGFocusListener() {
                        public void focusGained(FocusEvent e, SGNode node) {
                            if (node == shape2) {
                                latch.countDown();
                            }
                        }
                        public void focusLost(FocusEvent e, SGNode node) {
                        }
                    };
                    SGGroup sgGroup = new SGGroup();
                    
                    shape1.setID("shape1");
                    shape1.setShape(new Rectangle(0, 0, 100, 100));
                    shape1.addKeyListener(keyListener);
                    shape1.addFocusListener(focusListener);
                    sgGroup.add(shape1);
                    
                    shape2.requestFocus();
                    shape2.setID("shape2");
                    shape2.setShape(new Rectangle(100, 100, 100, 100));
                    shape2.addKeyListener(keyListener);
                    shape2.addFocusListener(focusListener);
                    sgGroup.add(shape2);
                    
                    JSGPanel panel = new JSGPanel();
                    frame.add(panel);
                    panel.setScene(sgGroup);
                    frame.pack();
                    frame.setVisible(true);
                    return null;
                }
            });
        latch.await();
    }
    
    static <T> T invokeAndWait(Callable<T> callable) throws Exception {
        try {
            FutureTask<T> future = new FutureTask<T>(callable);
            SwingUtilities.invokeLater(future);
            return future.get();
        } catch (ExecutionException e) {
            throw (Exception) e.getCause();
        }
    }

}
