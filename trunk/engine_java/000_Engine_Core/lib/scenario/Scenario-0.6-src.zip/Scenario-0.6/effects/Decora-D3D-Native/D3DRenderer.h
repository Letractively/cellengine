/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

#ifndef _D3DRENDERER_H
#define	_D3DRENDERER_H

#include "D3DDecora.h"
#include "D3DVB.h"

class D3DRenderer {
public:
    HRESULT Init(IDirect3DDevice9 *pd3dDevice);
            ~D3DRenderer() { Release(); }
    void    Release();

    HRESULT Enable();
    HRESULT Disable();

    HRESULT SetBlendMode(jint mode);
    HRESULT DrawTexture(IDirect3DTexture9 *pSrcTex, jboolean linear,
                        jfloat dx1, jfloat dy1, jfloat dx2, jfloat dy2,
                        jfloat tx1, jfloat ty1, jfloat tx2, jfloat ty2);
    HRESULT DrawTexture(IDirect3DTexture9 *pSrcTex1, jboolean linear1,
                        IDirect3DTexture9 *pSrcTex2, jboolean linear2,
                        jfloat dx1, jfloat dy1, jfloat dx2, jfloat dy2,
                        jfloat t1x1, jfloat t1y1, jfloat t1x2, jfloat t1y2,
                        jfloat t2x1, jfloat t2y1, jfloat t2x2, jfloat t2y2);

    D3DVB*  GetVB() { return pd3dVB; }
    IDirect3DDevice9*  GetDevice() { return lpd3dDevice; }

static
    HRESULT CreateInstance(IDirect3DDevice9 *pd3dDevice, D3DRenderer **ppd3dr);

private:
            D3DRenderer();

private:
    IDirect3DDevice9       *lpd3dDevice;
    D3DVB                  *pd3dVB;
    IDirect3DVertexShader9 *pVShader;
    IDirect3DVertexDeclaration9 *pDecl;
    DWORD                  dwSavedFVF;
};

#endif	/* _D3DRENDERER_H */
