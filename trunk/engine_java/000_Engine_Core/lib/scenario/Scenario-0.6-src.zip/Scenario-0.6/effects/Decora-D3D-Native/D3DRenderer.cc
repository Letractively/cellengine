/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

#include "com_sun_scenario_effect_impl_hw_d3d_D3DRenderer.h"
#include "D3DRenderer.h"
#include "PassThroughVS.h"

inline void matrixMult(D3DMATRIX& r, const D3DMATRIX& a, const D3DMATRIX& b)
{
    D3DMATRIX ret;
    for (int i=0; i<4; i++) {
        for (int j=0; j<4; j++) {
            ret.m[i][j] = 0.0f;
            for (int k=0; k<4; k++) {
                ret.m[i][j] += a.m[i][k] * b.m[k][j];
            }
        }
    }
    r = ret;
}
inline void matrixTranspose(D3DMATRIX& mat)
{
    float f;
#define SWAPIJ(I, J)               \
    do {                           \
        f = mat.m[I][J];           \
        mat.m[I][J] = mat.m[J][I]; \
        mat.m[J][I] = f;           \
    } while (0)

    SWAPIJ(0, 1);
    SWAPIJ(0, 2);
    SWAPIJ(0, 3);

    SWAPIJ(1, 2);
    SWAPIJ(1, 3);

    SWAPIJ(2, 3);
}

HRESULT
D3DRenderer::CreateInstance(IDirect3DDevice9 *pd3dDevice, D3DRenderer **ppVC)
{
    HRESULT res;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer::CreateInstance");

    *ppVC = new D3DRenderer();
    if (FAILED(res = (*ppVC)->Init(pd3dDevice))) {
        delete *ppVC;
        *ppVC = NULL;
    }
    return res;
}

D3DRenderer::D3DRenderer()
{
    lpd3dDevice = NULL;
    pd3dVB = NULL;
    pVShader = NULL;
    pDecl = NULL;
    dwSavedFVF = 0;
}

void
D3DRenderer::Release()
{
    SAFE_RELEASE(pDecl);
    SAFE_RELEASE(pVShader);
    SAFE_DELETE(pd3dVB);
    SAFE_RELEASE(lpd3dDevice);
}

HRESULT
D3DRenderer::Init(IDirect3DDevice9 *lpD3DDevice)
{
    HRESULT res;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer::Init");

    RETURN_STATUS_IF_NULL(lpD3DDevice, E_FAIL);

    Release();

    // save the device, addref so that it can't be released from under us
    this->lpd3dDevice = lpD3DDevice;
    lpd3dDevice->AddRef();

    res = D3DVB::CreateInstance(lpD3DDevice, &pd3dVB);
    RETURN_STATUS_IF_FAILED(res);

    res = lpd3dDevice->CreateVertexDeclaration(VDecl, &pDecl);
    RETURN_STATUS_IF_FAILED(res);

    res = lpd3dDevice->CreateVertexShader(g_vs30_passThrough, &pVShader);
    RETURN_STATUS_IF_FAILED(res);

    return res;
}

HRESULT
D3DRenderer::Enable()
{
    HRESULT res;
    D3DMATRIX w, p, v, wvp;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer::Enable");

    RETURN_STATUS_IF_NULL(lpd3dDevice, E_FAIL);
    RETURN_STATUS_IF_NULL(pVShader, E_FAIL);
    RETURN_STATUS_IF_NULL(pDecl, E_FAIL);

    lpd3dDevice->GetFVF(&dwSavedFVF);

    res = lpd3dDevice->BeginScene();
    RETURN_STATUS_IF_FAILED(res);

    lpd3dDevice->GetTransform(D3DTS_WORLD, &w);
    lpd3dDevice->GetTransform(D3DTS_VIEW, &v);
    lpd3dDevice->GetTransform(D3DTS_PROJECTION, &p);
    // create the WorldViewProj matrix
    // wvp = T(w * v * p);
    matrixMult(wvp, w, v);
    matrixMult(wvp, wvp, p);
    matrixTranspose(wvp);

    res = lpd3dDevice->SetVertexDeclaration(pDecl);
    RETURN_STATUS_IF_FAILED(res);
    res = lpd3dDevice->SetVertexShader(pVShader);
    RETURN_STATUS_IF_FAILED(res);
    res = lpd3dDevice->SetVertexShaderConstantF(0, (float*)wvp.m, 4);
    RETURN_STATUS_IF_FAILED(res);

    res = pd3dVB->CheckVB(lpd3dDevice);
    RETURN_STATUS_IF_FAILED(res);

    return res;
}

HRESULT
D3DRenderer::Disable()
{
    HRESULT res;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer::Disable");

    RETURN_STATUS_IF_NULL(lpd3dDevice, E_FAIL);

    res = lpd3dDevice->EndScene();

    lpd3dDevice->SetVertexShader(NULL);
    lpd3dDevice->SetFVF(dwSavedFVF);

    return res;
}

HRESULT
D3DRenderer::SetBlendMode(jint mode)
{
    TraceLn(DEC_TRACE_INFO, "D3DRenderer::SetBlendMode");

    RETURN_STATUS_IF_NULL(lpd3dDevice, E_FAIL);

    switch (mode) {
    case 0:
    default:
        TraceLn(DEC_TRACE_VERBOSE, "  disabled alpha blend");

        lpd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
        break;
    case 1:
        TraceLn(DEC_TRACE_VERBOSE, "  enabled alpha blend");

        lpd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
        lpd3dDevice->SetRenderState(D3DRS_SRCBLEND,  D3DBLEND_ONE);
        lpd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
        break;
    }

    return S_OK;
}

HRESULT
D3DRenderer::DrawTexture(IDirect3DTexture9 *pSrcTex, jboolean linear,
                         jfloat dx1, jfloat dy1, jfloat dx2, jfloat dy2,
                         jfloat tx1, jfloat ty1, jfloat tx2, jfloat ty2)
{
    HRESULT res;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer::DrawTexture 1");

    RETURN_STATUS_IF_NULL(lpd3dDevice, E_FAIL);
    RETURN_STATUS_IF_NULL(pd3dVB, E_FAIL);

    res = lpd3dDevice->SetTexture(0, pSrcTex);
    RETURN_STATUS_IF_FAILED(res);

    DWORD filter = linear ? D3DTEXF_LINEAR : D3DTEXF_POINT;
    lpd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, filter);
    lpd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, filter);
    lpd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_BORDER);
    lpd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_BORDER);

    TraceLn4(DEC_TRACE_VERBOSE, "  d : %f %f %f %f", dx1, dy1, dx2, dy2);
    TraceLn4(DEC_TRACE_VERBOSE, "  t1: %f %f %f %f", tx1, ty1, tx2, ty2);

    res = pd3dVB->DrawTexture(dx1, dy1, dx2, dy2,
                              tx1, ty1, tx2, ty2);
    // this ensures we flush immediately (while the shader is still active)
    res = pd3dVB->Render();

    return res;
}

HRESULT
D3DRenderer::DrawTexture(IDirect3DTexture9 *pSrcTex1, jboolean linear1,
                         IDirect3DTexture9 *pSrcTex2, jboolean linear2,
                         jfloat dx1, jfloat dy1, jfloat dx2, jfloat dy2,
                         jfloat t1x1, jfloat t1y1, jfloat t1x2, jfloat t1y2,
                         jfloat t2x1, jfloat t2y1, jfloat t2x2, jfloat t2y2)
{
    HRESULT res;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer::DrawTexture 2");

    RETURN_STATUS_IF_NULL(lpd3dDevice, E_FAIL);
    RETURN_STATUS_IF_NULL(pd3dVB, E_FAIL);

    if (FAILED(res = lpd3dDevice->SetTexture(0, pSrcTex1)) ||
        FAILED(res = lpd3dDevice->SetTexture(1, pSrcTex2)))
    {
        RlsTraceLn(DEC_TRACE_ERROR,
                   "D3DRenderer::DrawTexture 2: SetTexture failed");
        return res;
    }

    DWORD filter1 = linear1 ? D3DTEXF_LINEAR : D3DTEXF_POINT;
    lpd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, filter1);
    lpd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, filter1);
    lpd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_BORDER);
    lpd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_BORDER);
    DWORD filter2 = linear2 ? D3DTEXF_LINEAR : D3DTEXF_POINT;
    lpd3dDevice->SetSamplerState(1, D3DSAMP_MAGFILTER, filter2);
    lpd3dDevice->SetSamplerState(1, D3DSAMP_MINFILTER, filter2);
    lpd3dDevice->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_BORDER);
    lpd3dDevice->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_BORDER);

    TraceLn4(DEC_TRACE_VERBOSE, "  d : %f %f %f %f", dx1, dy1, dx2, dy2);
    TraceLn4(DEC_TRACE_VERBOSE, "  t1: %f %f %f %f", t1x1, t1y1, t1x2, t1y2);
    TraceLn4(DEC_TRACE_VERBOSE, "  t2: %f %f %f %f", t2x1, t2y1, t2x2, t2y2);

    res = pd3dVB->DrawTexture(dx1, dy1, dx2, dy2,
                              t1x1, t1y1, t1x2, t1y2,
                              t2x1, t2y1, t2x2, t2y2);

    // this ensures we flush immediately (while the shader is still active)
    res = pd3dVB->Render();

    lpd3dDevice->SetTexture(1, NULL);

    return res;
}

extern "C" {


JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_init
  (JNIEnv *env, jclass klass, jlong pd3dd)
{
    HRESULT res;
    IDirect3DDevice9 *pd3dDevice;
    D3DRenderer *pd3dRnd;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_init");

    pd3dDevice = (IDirect3DDevice9*)jlong_to_ptr(pd3dd);
    RETURN_STATUS_IF_NULL(pd3dDevice, 0L);

    res = D3DRenderer::CreateInstance(pd3dDevice, &pd3dRnd);
    if (FAILED(res)) {
        DebugPrintD3DError(res, "D3DRenderer_init: failed to create renderer");
        pd3dRnd = NULL;
    }

    return ptr_to_jlong(pd3dRnd);
}

JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_enable
  (JNIEnv *env, jclass klass, jlong pd3dr)
{
    D3DRenderer *pd3dRnd;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_enable");

    RETURN_STATUS_IF_NULL(pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr), E_FAIL);

    return pd3dRnd->Enable();
}

JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_disable
  (JNIEnv *env, jclass klass, jlong pd3dr)
{
    D3DRenderer *pd3dRnd;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_disable");

    RETURN_STATUS_IF_NULL(pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr), E_FAIL);

    return pd3dRnd->Disable();
}

JNIEXPORT void JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_dispose
  (JNIEnv *env, jclass klass, jlong pd3dr)
{
    D3DRenderer *pd3dRnd;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_dispose");

    pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr);
    SAFE_DELETE(pd3dRnd);
}


JNIEXPORT void JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_setBlendMode
  (JNIEnv *env, jclass klass,
   jlong pd3dr, jint mode)
{
    D3DRenderer *pd3dRnd;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_setBlendMode");

    pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr);
    RETURN_IF_NULL(pd3dRnd);

    pd3dRnd->SetBlendMode(mode);
}

JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_drawTexture
  (JNIEnv *env, jclass klass,
   jlong pd3dr,
   jlong pDst, jlong pSrc, jboolean linear,
   jfloat dx1, jfloat dy1, jfloat dx2, jfloat dy2,
   jfloat tx1, jfloat ty1, jfloat tx2, jfloat ty2)
{
    D3DRenderer *pd3dRnd;
    IDirect3DTexture9 *pSrcTex;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_drawTexture");

    RETURN_STATUS_IF_NULL(pSrcTex = (IDirect3DTexture9 *)jlong_to_ptr(pSrc), E_FAIL);
    RETURN_STATUS_IF_NULL(pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr), E_FAIL);

    return (jlong)pd3dRnd->DrawTexture(pSrcTex, linear,
                                       dx1, dy1, dx2, dy2,
                                       tx1, ty1, tx2, ty2);
}

JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_drawTexture2
  (JNIEnv *env, jclass klass,
   jlong pd3dr,
   jlong pDst,
   jlong pSrc1, jboolean linear1,
   jlong pSrc2, jboolean linear2,
   jfloat dx1, jfloat dy1, jfloat dx2, jfloat dy2,
   jfloat t1x1, jfloat t1y1, jfloat t1x2, jfloat t1y2,
   jfloat t2x1, jfloat t2y1, jfloat t2x2, jfloat t2y2)
{
    D3DRenderer *pd3dRnd;
    IDirect3DTexture9 *pSrc1Tex, *pSrc2Tex;

    TraceLn(DEC_TRACE_INFO, "D3DRenderer_drawTexture");

    RETURN_STATUS_IF_NULL(pSrc1Tex = (IDirect3DTexture9 *)jlong_to_ptr(pSrc1), E_FAIL);
    RETURN_STATUS_IF_NULL(pSrc2Tex = (IDirect3DTexture9 *)jlong_to_ptr(pSrc2), E_FAIL);
    RETURN_STATUS_IF_NULL(pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr), E_FAIL);

    return (jlong)pd3dRnd->DrawTexture(pSrc1Tex, linear1,
                                       pSrc2Tex, linear2,
                                       dx1, dy1, dx2, dy2,
                                       t1x1, t1y1, t1x2, t1y2,
                                       t2x1, t2y1, t2x2, t2y2);
}

JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DRenderer_getDevicePtr
  (JNIEnv *env, jclass klass, jlong pd3dr)
{
    D3DRenderer *pd3dRnd;
    RETURN_STATUS_IF_NULL(pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr), 0L);

    return ptr_to_jlong(pd3dRnd->GetDevice());
}

}
