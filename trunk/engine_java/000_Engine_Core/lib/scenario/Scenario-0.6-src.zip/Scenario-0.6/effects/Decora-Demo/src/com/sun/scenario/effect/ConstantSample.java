/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect;

import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

/**
 * An effect that filters out (i.e., replaces with a transparent value) all
 * pixels with brightness lower than the configurable threshold value.
 * 
 * @author Chris Campbell
 */
public class ConstantSample extends CoreEffect {

    private int outw, outh;
    private float sampX, sampY;

    /**
     * Constructs a new {@code ConstantSample} effect with the default
     * texture coordinates {@code (0.0, 0.0)}, and the default output
     * size {@code (100x100)} using the {@link Source source content}
     * as the input.
     * This is a shorthand equivalent to:
     * <pre>
     *     new ConstantSample(new Source(true))
     * </pre>
     */
    public ConstantSample() {
        this(new Source(true));
    }

    /**
     * Constructs a new {@code ConstantSample} effect with the default
     * texture coordinates {@code (0.0, 0.0)}, and the default output
     * size {@code (100x100)} using the specified {@code Effect}
     * as the input.
     * 
     * @param input the single input {@code Effect}
     * @throws IllegalArgumentException if {@code input} is null
     */
    public ConstantSample(Effect input) {
        super(input);
        updatePeerKey("ConstantSample");
        setOutputSize(100, 100);
    }

    /**
     * Sets the output size of this effect.
     * The output bounds will always be {@code (0, 0, w, h)}.
     * 
     * @param w the width of the output bounds
     * @param h the height of the output bounds
     */
    public void setOutputSize(int w, int h) {
        this.outw = w;
        this.outh = h;
    }

    /**
     * Returns the X coordinate of the constant sample coordinate.
     * 
     * @return the X coordinate of the texture sample location
     */
    public float getSampX() {
        return sampX;
    }

    /**
     * Returns the Y coordinate of the constant sample coordinate.
     * 
     * @return the Y coordinate of the texture sample location
     */
    public float getSampY() {
        return sampY;
    }

    /**
     * Sets the X coordinate of the constant sample coordinate.
     * 
     * @param sampX the X coordinate of the texture sample location
     */
    public void setSampX(float sampX) {
        this.sampX = sampX;
    }

    /**
     * Sets the Y coordinate of the constant sample coordinate.
     * 
     * @param sampY the Y coordinate of the texture sample location
     */
    public void setSampY(float sampY) {
        this.sampY = sampY;
    }

    @Override
    public Rectangle2D getBounds() {
        return new Rectangle(0, 0, outw, outh);
    }
    
    @Override
    public Image filter(GraphicsConfiguration config) {
        return filterInputs(config, 0).getImage();
    }
}
