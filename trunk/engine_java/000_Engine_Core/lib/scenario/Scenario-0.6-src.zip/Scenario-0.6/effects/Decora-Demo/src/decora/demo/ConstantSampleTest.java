/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package decora.demo;

import com.sun.scenario.effect.ConstantSample;
import com.sun.scenario.effect.Effect;
import com.sun.scenario.effect.SourceContent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import static javax.swing.SwingConstants.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Flar
 */
public class ConstantSampleTest extends AbstractDemo {

    private final ConstantSample constantsample;
    private final Image theSource;
    private JLabel texturecoords;

    public Image makeTinyImage() {
        // TODO: ideally we'd use the panel's GraphicsConfig, but that isn't
        // available until the frame has been made visible...
        //GraphicsConfiguration gc = getGraphicsConfiguration();
        GraphicsConfiguration gc =
            GraphicsEnvironment.getLocalGraphicsEnvironment().
            getDefaultScreenDevice().getDefaultConfiguration();
        Image src = Effect.createCompatibleImage(gc, 2, 2);
        Graphics2D gimg = (Graphics2D)src.getGraphics();
        gimg.setColor(Color.RED);
        gimg.fillRect(0, 0, 1, 1);
        gimg.setColor(Color.GREEN);
        gimg.fillRect(1, 0, 1, 1);
        gimg.setColor(Color.BLUE);
        gimg.fillRect(0, 1, 1, 1);
        gimg.setColor(Color.YELLOW);
        gimg.fillRect(1, 1, 1, 1);
        gimg.dispose();
        return src;
    }

    public ConstantSampleTest() {
        setRenderOffset(100, 50);
        this.constantsample = new ConstantSample();
        this.theSource = makeTinyImage();
        this.constantsample.setSourceContent(new SourceContent(theSource));
        this.constantsample.setOutputSize(200, 200);
        setPreferredSize(new Dimension(400, 300));
    }
    
    @Override
    ConstantSample getEffect() {
        return constantsample;
    }

    void updateCoordsLabel() {
        texturecoords.setText("Texture coords: ("+
                              constantsample.getSampX()+", "+
                              constantsample.getSampY()+")");
    }

    interface ValSetter {
        public void setValue(float v);
    }

    ValSetter textureX = new ValSetter() {
        public void setValue(float v) {
            constantsample.setSampX(v);
            updateCoordsLabel();
            repaint();
        }
    };

    ValSetter textureY = new ValSetter() {
        public void setValue(float v) {
            constantsample.setSampY(v);
            updateCoordsLabel();
            repaint();
        }
    };

    @Override
    void installControlPanels(JPanel panel) {
        texturecoords = new JLabel();

        JPanel xpanel = makeSlider(textureX, HORIZONTAL);
        JPanel ypanel = makeSlider(textureY, VERTICAL);
        JSlider xslider = findSlider(xpanel);
        JSlider yslider = findSlider(ypanel);

        JPanel sourcepanel = new JPanel(new OrientedFlowLayout(VERTICAL));
        int sw = theSource.getWidth(null);
        int sh = theSource.getHeight(null);
        int sdw = xslider.getPreferredSize().width * 10 / 12;
        int sdh = yslider.getPreferredSize().height * 10 / 12;
        SourceDisplay sd = new SourceDisplay(sdw, sdh);
        sourcepanel.add(sd);
        sourcepanel.add(new JLabel(sw+"x"+sh+" Source Image"));
        sourcepanel.add(texturecoords);

        ControlLayout cl = new ControlLayout(xpanel, ypanel, sd, sourcepanel);
        JPanel controls = new JPanel(cl);
        controls.add(xpanel);
        controls.add(ypanel);
        controls.add(sourcepanel);

        JPanel controlcenterer = new JPanel();
        controlcenterer.add(controls);
        panel.add(controlcenterer, BorderLayout.SOUTH);
        updateCoordsLabel();
    }

    JPanel makeSlider(final ValSetter setter, int orientation) {
        int floworientation = (orientation == HORIZONTAL) ? VERTICAL : HORIZONTAL;
        JPanel sliderpanel = new JPanel(new OrientedFlowLayout(floworientation));
        final JSlider slider = new JSlider(orientation, -10, 110, 0);
        if (orientation == VERTICAL) {
            slider.setInverted(true);
        }
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                JSlider slider = (JSlider) e.getSource();
                setter.setValue(slider.getValue() / 100f);
            }
        });
        Hashtable ht = new Hashtable();
        ht.put(0, new JLabel("0.0"));
        ht.put(100, new JLabel("1.0"));
        slider.setLabelTable(ht);
        slider.setPaintLabels(true);
        slider.setMajorTickSpacing(10);
        slider.setPaintTicks(true);
        JCheckBox cb = new JCheckBox("NaN");
        cb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JCheckBox cb = (JCheckBox) e.getSource();
                if (cb.isSelected()) {
                    slider.setEnabled(false);
                    setter.setValue(Float.NaN);
                } else {
                    slider.setEnabled(true);
                    setter.setValue(slider.getValue() / 100f);
                }
            }
        });
        sliderpanel.add(cb);
        sliderpanel.add(slider);
        return sliderpanel;
    }

    static JSlider findSlider(JPanel p) {
        for (Component comp : p.getComponents()) {
            if (comp instanceof JSlider) {
                return (JSlider) comp;
            }
        }
        return null;
    }
 
    public class ControlLayout implements LayoutManager {
        JPanel xsliderpanel;
        JPanel ysliderpanel;
        SourceDisplay sourcedisplay;
        JPanel sourcepanel;
        JSlider xslider;
        JSlider yslider;

        public ControlLayout(JPanel xpanel, JPanel ypanel,
                             SourceDisplay sd, JPanel sourcepanel)
        {
            this.xsliderpanel = xpanel;
            this.ysliderpanel = ypanel;
            this.sourcedisplay = sd;
            this.sourcepanel = sourcepanel;
            this.xslider = findSlider(xpanel);
            this.yslider = findSlider(ypanel);
        }

        public Dimension doLayout(Container parent,
                                  boolean isPreferred,
                                  boolean doSetBounds)
        {
            Dimension xdim = (isPreferred)
                    ? xsliderpanel.getPreferredSize()
                    : xsliderpanel.getMinimumSize();
            Dimension ydim = (isPreferred)
                    ? ysliderpanel.getPreferredSize()
                    : ysliderpanel.getMinimumSize();
            Dimension sdim = (isPreferred)
                    ? sourcepanel.getPreferredSize()
                    : sourcepanel.getMinimumSize();
            xsliderpanel.setSize(xdim);
            xsliderpanel.validate();
            ysliderpanel.setSize(ydim);
            ysliderpanel.validate();
            sourcepanel.setSize(sdim);
            sourcepanel.validate();
            int xsw = xslider.getWidth();
            int ysh = yslider.getHeight();
            int sdw = sourcedisplay.getWidth();
            int sdh = sourcedisplay.getHeight();
            int x0 = xslider.getX() + (xsw - sdw) / 2;
            int y0 = yslider.getY() + (ysh - sdh) / 2;
            int imgoffx = sourcedisplay.getX();
            int imgoffy = sourcedisplay.getY();
            int pad = Math.max(Math.max(imgoffy, y0), Math.max(imgoffx, x0));
            int imgx = ydim.width + pad;
            int imgy = xdim.height + pad;
            int w = Math.max(imgx - x0 + xdim.width,
                             imgx - imgoffx + sdim.width);
            int h = Math.max(imgy - y0 + ydim.height,
                             imgy - imgoffy + sdim.height);
            if (doSetBounds) {
                Dimension pdim = parent.getSize();
                if (isPreferred && (w > pdim.width || h > pdim.height)) {
                    return null;
                }
                int origx = (pdim.width - w) / 2;
                int origy = (pdim.height - h) / 2;
                xsliderpanel.setBounds(origx + imgx - x0, origy,
                                       xdim.width, xdim.height);
                ysliderpanel.setBounds(origx, origy + imgy - y0,
                                       ydim.width, ydim.height);
                sourcepanel.setBounds(origx + imgx - imgoffx,
                                      origy + imgy - imgoffy,
                                      sdim.width, sdim.height);
            }
            return new Dimension(w, h);
        }

        public Dimension minimumLayoutSize(Container parent) {
            return doLayout(parent, false, false);
        }

        public Dimension preferredLayoutSize(Container parent) {
            return doLayout(parent, true, false);
        }

        public void layoutContainer(Container parent) {
            if (doLayout(parent, true, true) == null) {
                doLayout(parent, false, true);
            }
        }

        public void removeLayoutComponent(Component comp) {}

        public void addLayoutComponent(String s, Component comp) {}
    }

    public class OrientedFlowLayout implements LayoutManager {
        int orientation;

        public OrientedFlowLayout(int orientation) {
            this.orientation = orientation;
        }

        public Dimension minimumLayoutSize(Container parent) {
            return accumulate(parent, false);
        }

        public Dimension preferredLayoutSize(Container parent) {
            return accumulate(parent, true);
        }

        public Dimension accumulate(Container parent, boolean isPreferred) {
            int pw = 0, ph = 0;
            for (Component comp : parent.getComponents()) {
                Dimension compsize = (isPreferred
                    ? comp.getPreferredSize()
                    : comp.getMinimumSize());
                if (orientation == HORIZONTAL) {
                    pw += compsize.width;
                    if (ph < compsize.height) ph = compsize.height;
                } else {
                    if (pw < compsize.width) pw = compsize.width;
                    ph += compsize.height;
                }
            }
            return new Dimension(pw, ph);
        }

        public void layoutContainer(Container parent) {
            Dimension containersize = parent.getSize();
            boolean isPreferred = true;
            Dimension layoutsize = accumulate(parent, true);
            if (orientation == HORIZONTAL) {
                isPreferred = (containersize.width >= layoutsize.width);
            } else {
                isPreferred = (containersize.height >= layoutsize.height);
            }
            if (!isPreferred) {
                layoutsize = accumulate(parent, false);
            }
            int x = (containersize.width - layoutsize.width) / 2;
            int y = (containersize.height - layoutsize.height) / 2;
            for (Component comp : parent.getComponents()) {
                Dimension compsize = (isPreferred
                    ? comp.getPreferredSize()
                    : comp.getMinimumSize());
                if (orientation == HORIZONTAL) {
                    y = (containersize.height - compsize.height) / 2;
                } else {
                    x = (containersize.width - compsize.width) / 2;
                }
                comp.setBounds(x, y, compsize.width, compsize.height);
                x += compsize.width;
                y += compsize.height;
            }
        }

        public void removeLayoutComponent(Component comp) {}

        public void addLayoutComponent(String s, Component comp) {}
    }
    public class SourceDisplay extends JPanel {
        int w;
        int h;

        public SourceDisplay(int w, int h) {
            this.w = w;
            this.h = h;
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(w, h);
        }
        @Override
        public void paintComponent(Graphics g) {
            g.drawImage(theSource, 0, 0, w, h, null);
        }
    }
    public static void main(String[] args) {
        launch(ConstantSampleTest.class);
    } 
}
