/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

#include "D3DVB.h"

HRESULT
D3DVB::CreateInstance(IDirect3DDevice9 *pd3dDevice, D3DVB **ppVC)
{
    HRESULT res;

    TraceLn(DEC_TRACE_INFO, "D3DVB::CreateInstance");

    *ppVC = new D3DVB();
    if (FAILED(res = (*ppVC)->Init(pd3dDevice))) {
        delete *ppVC;
        *ppVC = NULL;
    }
    return res;
}

D3DVB::D3DVB()
{
    lpD3DDevice = NULL;
    lpD3DVertexBuffer = NULL;
    lpSavedVB = NULL;
    pVertices = NULL;
    color = 0xffffffff;
}

HRESULT
D3DVB::RestoreVB(IDirect3DDevice9 *lpD3DDevice)
{
    HRESULT res;
    UINT offset = 0, stride = 0;
    IDirect3DVertexBuffer9  *lpVB;
    
    res = lpD3DDevice->GetStreamSource(0, &lpVB, &offset, &stride);
    if (FAILED(res)) {
        lpVB = NULL;
    }
    if (lpSavedVB != NULL && lpSavedVB != lpVB) {
        res = lpD3DDevice->SetStreamSource(0, lpSavedVB, 0,
                                           sizeof(J2DLVERTEX));
    }
    SAFE_RELEASE(lpVB);
    SAFE_RELEASE(lpSavedVB);
    return res;
}

HRESULT
D3DVB::CheckVB(IDirect3DDevice9 *lpD3DDevice)
{
    HRESULT res;
    UINT offset = 0, stride = 0;
    IDirect3DVertexBuffer9  *lpVB;

    TraceLn(DEC_TRACE_INFO, "D3DVB::CheckVB");
    
    if (this->lpD3DDevice != lpD3DDevice) {
        // we're trying to render to a different
        // device, fail!
        return E_FAIL;
    }

    res = lpD3DDevice->GetStreamSource(0, &lpVB, &offset, &stride);
    if (FAILED(res)) {
        lpVB = NULL;
    }
    // the currently set vb is ours already, just go on, nothing to do
    if (lpD3DVertexBuffer != NULL && lpVB == lpD3DVertexBuffer) {
        TraceLn(DEC_TRACE_VERBOSE, "  current VB is ours, nothing to do");
        SAFE_RELEASE(lpVB);
        return S_OK;
    }

    // REMIND: this optimization below (reusing the existing VB) didn't yield
    // much pertformance-wise, and actually caused some rendering issues
    // so it is currently disabled.
    
    // see if we can use an existing vertex buffer
//    if (lpVB != NULL) {
//        D3DVERTEXBUFFER_DESC vbDesc;
//
//        ZeroMemory(&vbDesc, sizeof(vbDesc));
//        lpVB->GetDesc(&vbDesc);
//
//        if (offset == 0 && stride == sizeof(J2DLVERTEX) &&
//            vbDesc.FVF == D3DFVF_DCRLVERTEX)
//        {
//            TraceLn(DEC_TRACE_VERBOSE, "  reusing existing VB");
//            // yes, we can; get rid of the old one (flush first)
//            Render(RESET_ACTION);
//            SAFE_RELEASE(lpD3DVertexBuffer);
//
//            SAFE_DELETE_ARR(pVertices);
//            maxNumOfVertices = vbDesc.Size / sizeof(J2DLVERTEX);
//            pVertices = new J2DLVERTEX[maxNumOfVertices];
//            lpD3DVertexBuffer = lpVB;
//            // don't need addref here since we already increased ref when
//            // GetStreamSource was called
//            // lpVB->AddRef();
//            return S_OK;
//        }
////        lpSavedVB = lpVB;
////        lpSavedVB->AddRef();
//    }
    // release the device's vb, we will not be using it
    SAFE_RELEASE(lpVB);

    // if we don't have our own vb, create it
    if (lpD3DVertexBuffer == NULL) {
        D3DCAPS9 caps;
        
        TraceLn(DEC_TRACE_VERBOSE, "  creating our own VB");
        ZeroMemory(&caps, sizeof(caps));
        lpD3DDevice->GetDeviceCaps(&caps);
        
        D3DPOOL pool = (caps.DeviceType == D3DDEVTYPE_HAL) ?
            D3DPOOL_DEFAULT : D3DPOOL_SYSTEMMEM;
        // usage depends on whether we use hw or sw vertex processing
        maxNumOfVertices = DEF_MAX_VERT_NUM;
        SAFE_DELETE_ARR(pVertices);
        pVertices = new J2DLVERTEX[maxNumOfVertices];
        res = lpD3DDevice->CreateVertexBuffer(maxNumOfVertices*sizeof(J2DLVERTEX),
                D3DUSAGE_DYNAMIC|D3DUSAGE_WRITEONLY, D3DFVF_DCRLVERTEX,
                pool, &lpD3DVertexBuffer, NULL);
        RETURN_STATUS_IF_FAILED(res);
    }
    
    res = lpD3DDevice->SetStreamSource(0, lpD3DVertexBuffer, 0,
                                       sizeof(J2DLVERTEX));
    RETURN_STATUS_IF_FAILED(res);

    return lpD3DDevice->SetFVF(D3DFVF_DCRLVERTEX);
}

HRESULT
D3DVB::Init(IDirect3DDevice9 *lpD3DDevice)
{

    RETURN_STATUS_IF_NULL(lpD3DDevice, E_FAIL);

    ReleaseDefPoolResources();
    
    // save the device, addref so that it can't be released from under us
    this->lpD3DDevice = lpD3DDevice;
    lpD3DDevice->AddRef();

    firstPendingVertex = 0;
    firstUnusedVertex = 0;
    numOfTriangles = 0;
    maxNumOfVertices = DEF_MAX_VERT_NUM;

    return CheckVB(lpD3DDevice);
}

void
D3DVB::ReleaseDefPoolResources()
{
    SAFE_RELEASE(lpD3DVertexBuffer);
    SAFE_RELEASE(lpD3DDevice);
    SAFE_DELETE_ARR(pVertices);
    firstPendingVertex = 0;
    firstUnusedVertex = 0;
    numOfTriangles = 0;
}

HRESULT
D3DVB::DrawTexture(float x1, float y1, float x2, float y2,
                   float u1, float v1, float u2, float v2)
{
    HRESULT res;
    if (SUCCEEDED(res = EnsureCapacity())) {
        // correct texel to pixel mapping; see D3DContext::SetTransform()
        // for non-id tx case
        // REMIND need to fix mapping for non-tx case!
//        if (pCtx->IsIdentityTx()) {
            x1 -= 0.5f;
            y1 -= 0.5f;
            x2 -= 0.5f;
            y2 -= 0.5f;
//        }

        ADD_TRIANGLE_XYUVC(x1, y1, x2, y1, x1, y2,
                           u1, v1, u2, v1, u1, v2,
                           color);
        ADD_TRIANGLE_XYUVC(x1, y2, x2, y1, x2, y2,
                           u1, v2, u2, v1, u2, v2,
                           color);
    }
    return res;
}

HRESULT
D3DVB::DrawTexture(float  x1, float  y1, float  x2, float  y2,
                   float u11, float v11, float u12, float v12,
                   float u21, float v21, float u22, float v22)
{
    HRESULT res;
    if (SUCCEEDED(res = EnsureCapacity())) {
        // correct texel to pixel mapping; see D3DContext::SetTransform()
        // for non-id tx case
        // REMIND need to fix mapping for non-tx case!
//        if (pCtx->IsIdentityTx()) {
            x1 -= 0.5f;
            y1 -= 0.5f;
            x2 -= 0.5f;
            y2 -= 0.5f;
//        }

        ADD_TRIANGLE_XYUVUVC(x1, y1, x2, y1, x1, y2,
                             u11, v11, u12, v11, u11, v12,
                             u21, v21, u22, v21, u21, v22,
                             color);
        ADD_TRIANGLE_XYUVUVC(x1, y2, x2, y1, x2, y2,
                             u11, v12, u12, v11, u12, v12,
                             u21, v22, u22, v21, u22, v22,
                             color);
    }
    return res;
}

HRESULT
D3DVB::Render(int actionType)
{
    J2DLVERTEX *lpVert;
    HRESULT res;
    DWORD dwLockFlags;
    UINT pendingVertices = firstUnusedVertex - firstPendingVertex;
    
    TraceLn(DEC_TRACE_INFO, "D3DVB::Render");
    
    if (lpD3DDevice == NULL || lpD3DVertexBuffer == NULL) {
        return D3D_OK;
    }
    
    // nothing to render
    if (pendingVertices == 0) {
        if (actionType == RESET_ACTION) {
            firstPendingVertex = 0;
            firstUnusedVertex = 0;
        }
        return D3D_OK;
    }

    if (firstPendingVertex == 0) {
        // no data in the buffer yet, we don't care about
        // vertex buffer's contents
        dwLockFlags = D3DLOCK_DISCARD;
    } else {
        // append to the existing data in the vertex buffer
        dwLockFlags = D3DLOCK_NOOVERWRITE;
    }

    if (SUCCEEDED(res =
        lpD3DVertexBuffer->Lock((UINT)firstPendingVertex*sizeof(J2DLVERTEX),
                                (UINT)pendingVertices*sizeof(J2DLVERTEX),
                                (void**)&lpVert, dwLockFlags)))
    {
        // copy only new vertices
        memcpy((void *)lpVert,
               (void *)(pVertices + firstPendingVertex),
               pendingVertices * sizeof(J2DLVERTEX));
        lpD3DVertexBuffer->Unlock();

        TraceLn3(DEC_TRACE_VERBOSE,
                "  firstPendingVertex=%d numOfTriangles=%d firstUnusedVertex=%d",
                firstPendingVertex, numOfTriangles, firstUnusedVertex)
        res = lpD3DDevice->DrawPrimitive(D3DPT_TRIANGLELIST,
                                         firstPendingVertex, numOfTriangles);
        numOfTriangles = 0;
    } else {
        DebugPrintD3DError(res, "Can't lock vertex buffer");
    }

    if (actionType == RESET_ACTION) {
        firstPendingVertex = 0;
        firstUnusedVertex = 0;
    } else {
        firstPendingVertex = firstUnusedVertex;
    }

    return res;
}

HRESULT D3DVB::EnsureCapacity()
{
    HRESULT res = D3D_OK;
    UINT vNum = 2*3; // two triangles, 3 vertices each == 6 vertices

    TraceLn4(DEC_TRACE_VERBOSE,
            "D3DVC::EnsureCapacity "\
            "firstPendingVertex= %d, total pending vs: %d, "\
            "firstUnusedVertex: %d, requested vertices: %d",
            firstPendingVertex, (firstUnusedVertex-firstPendingVertex),
            firstUnusedVertex, vNum);

    if ((firstUnusedVertex + vNum) >= maxNumOfVertices) {
        // if we can't fit new vertices in the vertex buffer,
        // render whatever we have in the buffer and start
        // from the beginning of the vertex buffer
        res = Render(RESET_ACTION);
    }

    return res;
}
