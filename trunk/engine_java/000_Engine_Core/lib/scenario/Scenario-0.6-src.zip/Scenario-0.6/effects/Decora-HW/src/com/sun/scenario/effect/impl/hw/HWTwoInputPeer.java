/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw;

import com.sun.scenario.effect.Effect;
import com.sun.scenario.effect.impl.ImageData;
import java.awt.GraphicsConfiguration;
import java.awt.Rectangle;
import java.awt.image.VolatileImage;
import sun.java2d.DestSurfaceProvider;
import sun.java2d.pipe.BufferedContext;
import sun.java2d.pipe.RenderQueue;
import sun.java2d.pipe.hw.AccelSurface;

/**
 * @author Chris Campbell
 */
public abstract class HWTwoInputPeer extends HWEffectPeer {
    
    private Shader shader;

    protected HWTwoInputPeer(GraphicsConfiguration gc) {
        super(gc);
    }
    
    @Override
    ImageData filterImpl(Effect effect, ImageData... inputs) {
        setEffect(effect); // TODO: this is still awkward...
        
        VolatileImage src0 = (VolatileImage)inputs[0].getImage();
        Rectangle src0Bounds = inputs[0].getBounds();
        VolatileImage src1 = (VolatileImage)inputs[1].getImage();
        Rectangle src1Bounds = inputs[1].getBounds();

        Rectangle dstBounds = getDestBounds();
        final int dstw = dstBounds.width;
        final int dsth = dstBounds.height;
        
        VolatileImage dst = getDestImageFromPool(dstw, dsth);
        dst.validate(getGraphicsConfig()); // TODO: check return value

        if (dst instanceof DestSurfaceProvider) {
            DestSurfaceProvider ssrc0 = (DestSurfaceProvider)src0;
            DestSurfaceProvider ssrc1 = (DestSurfaceProvider)src1;
            DestSurfaceProvider sdst = (DestSurfaceProvider)dst;
            final AccelSurface src0Data = (AccelSurface)ssrc0.getDestSurface();
            final AccelSurface src1Data = (AccelSurface)ssrc1.getDestSurface();
            final AccelSurface dstData = (AccelSurface)sdst.getDestSurface();

            setInputBounds(0, src0Bounds);
            setInputBounds(1, src1Bounds);
            setInputNativeBounds(0, src0Data.getNativeBounds());
            setInputNativeBounds(1, src1Data.getNativeBounds());
            final float[] src0Rect = getSourceRegion(0);
            final float[] src1Rect = getSourceRegion(1);

            RenderQueue rq = dstData.getContext().getRenderQueue();
            rq.lock();
            try {
                dstData.getContext().saveState();
                BufferedContext.validateContext(dstData);
                rq.flushAndInvokeNow(new Runnable() {
                    public void run() {
                        HWRenderer renderer = getRenderer();
                        renderer.enable();
                        if (shader == null) {
                            shader = createShader();
                        }
                        shader.enable();
                        updateShader(shader);
                        if (!dstData.isSurfaceLost()) {
                            float dx1 = 0;
                            float dy1 = 0;
                            // TODO: dstw/h should be based on result size,
                            // not physical bounds of dest image...
                            float dx2 = dstw;
                            float dy2 = dsth;
                            float t0x1 = src0Rect[0];
                            float t0y1 = src0Rect[1];
                            float t0x2 = src0Rect[2];
                            float t0y2 = src0Rect[3];
                            float t1x1 = src1Rect[0];
                            float t1y1 = src1Rect[1];
                            float t1x2 = src1Rect[2];
                            float t1y2 = src1Rect[3];

                            renderer.drawTexture(dstData,
                                                 src0Data, isSamplerLinear(0),
                                                 src1Data, isSamplerLinear(1),
                                                 dx1, dy1, dx2, dy2,
                                                 t0x1, t0y1, t0x2, t0y2,
                                                 t1x1, t1y1, t1x2, t1y2);
                        }
                        shader.disable();
                        renderer.disable();
                    }
                });
                dstData.getContext().restoreState();
            } finally {
                rq.unlock();
            }
        }
        
        return new ImageData(dst, dstBounds);
    }
}
