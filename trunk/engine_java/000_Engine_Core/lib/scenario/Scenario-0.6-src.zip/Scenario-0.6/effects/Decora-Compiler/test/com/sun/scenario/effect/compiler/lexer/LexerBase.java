/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.compiler.lexer;

import static org.junit.Assert.*;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.Token;
import com.sun.scenario.effect.compiler.JSLLexer;

public abstract class LexerBase {

    protected void assertRangeOfCharactersRecognized(char low, char high)
        throws Exception {

        for (char ch = low; ch <= high; ++ch) {
            assertRecognized(ch);
        }
    }

    protected void recognizeRange(char low, char high) throws Exception {
        for (char ch = low; ch <= high; ++ch) {
            recognize(ch);
        }
    }

    protected void assertRecognized(char ch) throws Exception {
        assertRecognized(String.valueOf(ch));
    }

    protected Token recognize(char ch) throws Exception {
        return recognize(String.valueOf(ch));
    }

    protected void assertRecognized(String text) throws Exception {
        Token token = recognize(text);
        assertEquals(text, token.getText());

        if (expectedTokenType() != Integer.MIN_VALUE) {
            assertEquals(expectedTokenType(), token.getType());
        }
    }

    protected Token recognize(String text) throws Exception {
        JSLLexer lexer = lexerOver(text);
        fireLexerRule(lexer);
        lexer = lexerOver(text);
        return lexer.nextToken();
    }

    private JSLLexer lexerOver(String text) {
        JSLLexer lexer = new JSLLexer();
        lexer.setCharStream(new ANTLRStringStream(text));
        return lexer;
    }

    protected abstract void fireLexerRule(JSLLexer lexer) throws Exception;

    protected int expectedTokenType() {
        return Integer.MIN_VALUE;
    }
}
