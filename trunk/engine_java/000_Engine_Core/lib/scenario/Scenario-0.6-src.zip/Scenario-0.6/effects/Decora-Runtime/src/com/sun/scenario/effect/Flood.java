/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

/**
 * An effect that renders a rectangular region that is filled ("flooded")
 * with the given {@code Paint}.  This is equivalent to rendering a
 * filled rectangle into an image and using an {@code Identity} effect,
 * except that it is more convenient and potentially much more efficient.
 * 
 * @author Chris Campbell
 */
public class Flood extends Effect {
    
    private Paint paint;
    
    /**
     * Constructs a new {@code Flood} effect using the given {@code Paint}.
     * 
     * @param paint the {@code Paint} used to flood the region
     * @throws IllegalArgumentException if {@code paint} is null
     */
    public Flood(Paint paint) {
        if (paint == null) {
            throw new IllegalArgumentException("Paint must be non-null");
        }
        this.paint = paint;
    }
    
    /**
     * Returns the {@code Paint} used to flood the region.
     * 
     * @return the flood {@code Paint}
     */
    public Paint getPaint() {
        return paint;
    }

    /**
     * Sets the {@code Paint} used to flood the region.
     *
     * @param paint the flood {@code Paint}
     * @throws IllegalArgumentException if {@code paint} is null
     */
    public void setPaint(Paint paint) {
        if (paint == null) {
            throw new IllegalArgumentException("Paint must be non-null");
        }
        Paint old = this.paint;
        this.paint = paint;
        firePropertyChange("paint", old, paint);
    }
    
    @Override
    public int needsSourceContent() {
        // TODO: but it does need access to the untransformed source bounds,
        // so maybe we need a new constant?
        return NONE;
    }

    @Override
    public Rectangle2D getBounds() {
        Rectangle2D r = new Rectangle2D.Float();
        r.setRect(getSourceContent().getUntransformedBounds());
        return r;
    }
    
    @Override
    public Image filter(GraphicsConfiguration config) {
        Rectangle2D fullBounds = getBounds();
        Rectangle tmp = fullBounds.getBounds();
        int w = tmp.width;
        int h = tmp.height;
        Image dst = getCompatibleImage(config, w, h);
        
        Graphics2D gdst = (Graphics2D)dst.getGraphics();
        gdst.setComposite(AlphaComposite.Src);
        gdst.setPaint(paint);
        gdst.fillRect(0, 0, w, h);
        gdst.dispose();
        
        return dst;
    }
    
    @Override
    public AccelType getAccelType(GraphicsConfiguration config) {
        // TODO: not sure what to return here...
        return AccelType.NONE;
    }
}
