/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package decora.demo;

import com.sun.scenario.effect.Effect;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;

/**
 * @author Chris Campbell
 */
public abstract class AbstractDemo extends JPanel {

    private static boolean perf = false;
    private static Color textColor = new Color(100, 100, 100);
    
    static {
        try {
            perf = Boolean.getBoolean("decora.demo.perf");
        } catch (SecurityException ignore) {
        }
    }

    private int xoff, yoff;
    private Color checkerColor;

    protected AbstractDemo() {
        setBackground(Color.BLACK);
        setCheckerColor(new Color(19, 19, 19));
        setRenderOffset(20, 20);
    }

    public void setRenderOffset(int x, int y) {
        this.xoff = x;
        this.yoff = y;
    }
    
    public void setCheckerColor(Color checker) {
        this.checkerColor = checker;
    }

    abstract Effect getEffect();

    void installControlPanels(JPanel panel) {}

    private GraphicsConfiguration getDefaultConfig() {
        return
            GraphicsEnvironment.getLocalGraphicsEnvironment().
            getDefaultScreenDevice().getDefaultConfiguration();
    }
    
    BufferedImage loadImage(String filename) {
        try {
            return ImageIO.read(getClass().getResource(filename));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
        
    Image makeSrcImage(String filename) {
        BufferedImage image = loadImage(filename);
        // TODO: ideally we'd use the panel's GraphicsConfig, but that isn't
        // available until the frame has been made visible...
        //GraphicsConfiguration gc = getGraphicsConfiguration();
        GraphicsConfiguration gc = getDefaultConfig();
        Image src = Effect.createCompatibleImage(gc, image.getWidth(), image.getHeight());
        Graphics2D gimg = (Graphics2D)src.getGraphics();
        gimg.drawImage(image, 0, 0, null);
        gimg.dispose();
        return src;
    }
    
    Image makeTextImage(String text) {
        // TODO: ideally we'd use the panel's GraphicsConfig, but that isn't
        // available until the frame has been made visible...
        //GraphicsConfiguration gc = getGraphicsConfiguration();
        GraphicsConfiguration gc = getDefaultConfig();
        Image src = Effect.createCompatibleImage(gc, 700, 200);
        Graphics2D gimg = (Graphics2D)src.getGraphics();
        gimg.setComposite(AlphaComposite.Clear);
        gimg.fillRect(0, 0, 700, 200);
        gimg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                              RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gimg.setComposite(AlphaComposite.SrcOver);
        gimg.setColor(Color.RED);
        gimg.setFont(new Font("SansSerif", Font.BOLD, 120));
        gimg.drawString(text, 20, 140);
        gimg.dispose();
        return src;
    }
    
    public static void launch(Class<? extends AbstractDemo> klass) {
        try {
            AbstractDemo demo = (AbstractDemo)klass.newInstance();
            createAndShowGUI(demo);
        } catch (Exception e) {
            throw new IllegalArgumentException("Problem constructing " +
                    "instance of "+klass+": ", e);
        }
    }
    
    static void initLookAndFeel() {
        MetalLookAndFeel.setCurrentTheme(new CharcoalTheme());
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
        }
    }
    
    private static void createAndShowGUI(final AbstractDemo demo) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                initLookAndFeel();
                makeFrame(demo).setVisible(true);
            }
        });
    }

    private static JFrame makeFrame(AbstractDemo demo) {
        JFrame f = new JFrame(demo.getClass().getSimpleName());
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(demo, BorderLayout.CENTER);
        demo.installControlPanels(panel);
        f.setContentPane(panel);
        f.pack();
        f.setLocationRelativeTo(null);
        return f;
    }
    
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(getBackground());
        g2.fillRect(0, 0, getWidth(), getHeight());
        if (checkerColor != null) {
            int s = 60;
            int s2 = 2*s;
            g2.setColor(checkerColor);
            for (int y = 0; y < getHeight()+s; y += s) {
                int x0 = y % s2;
                for (int x = x0; x < getWidth()+s; x += s2) {
                    g2.fillRect(x-20, y-20, s, s);
                }
            }
        }

        Effect effect = getEffect();
        Rectangle r = effect.getBounds().getBounds();
        int x = xoff + r.x;
        int y = yoff + r.y;
        
        if (perf) {
            // warmup
            long start = System.currentTimeMillis();
            long now;
            do {
                effect.render(g2, x, y, false);
                now = System.currentTimeMillis();
                Toolkit.getDefaultToolkit().sync();
            } while (now - start < 1000);

            start = System.currentTimeMillis();
            int count = 0;
            do {
                effect.render(g2, x, y, false);
                count++;
                now = System.currentTimeMillis();
            } while (now - start < 5000);
            Toolkit.getDefaultToolkit().sync();
            long end = System.currentTimeMillis();
            System.err.println("total: "+(end - start)+" for "+count+" runs");
            System.err.println("avg == "+((end-start)/(double) count)+" ms per run");
        } else {
            effect.render(g2, x, y, false);
        }

        GraphicsConfiguration gc = g2.getDeviceConfiguration();
        String backend = "Using " + effect.getAccelType(gc) + " backend";
        g2.setColor(textColor);
        g2.drawString(backend, 5, getHeight() - 5);
    }
}

class CharcoalTheme extends DefaultMetalTheme {
    public String getName() { return "Charcoal"; }

    private final ColorUIResource primary1 = new ColorUIResource(66, 33, 66);
    private final ColorUIResource primary2 = new ColorUIResource(90, 86, 99);
    private final ColorUIResource primary3 = new ColorUIResource(99, 99, 99);

    private final ColorUIResource secondary1 = new ColorUIResource(0, 0, 0);
    private final ColorUIResource secondary2 = new ColorUIResource(51, 51, 51);
    private final ColorUIResource secondary3 = new ColorUIResource(32, 32, 32);

    private final ColorUIResource white = new ColorUIResource(142, 142, 142);
    private final ColorUIResource black = new ColorUIResource(120, 120, 120);

    protected ColorUIResource getPrimary1() { return primary1; }
    protected ColorUIResource getPrimary2() { return primary2; }
    protected ColorUIResource getPrimary3() { return primary3; }

    protected ColorUIResource getSecondary1() { return secondary1; }
    protected ColorUIResource getSecondary2() { return secondary2; }
    protected ColorUIResource getSecondary3() { return secondary3; }

    protected ColorUIResource getBlack() { return black; }
    protected ColorUIResource getWhite() { return white; }
}
