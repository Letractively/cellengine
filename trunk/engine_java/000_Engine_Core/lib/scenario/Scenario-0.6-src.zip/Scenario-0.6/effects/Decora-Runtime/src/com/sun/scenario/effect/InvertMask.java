/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

/**
 * An effect that returns a mask that is the inverse of the input (i.e.,
 * opaque areas of the input become transparent and vice versa).
 * 
 * @author Chris Campbell
 */
public class InvertMask extends Effect {
    
    private int pad;
    
    /**
     * Constructs a new {@code InvertMask} effect with the default pad (10),
     * using the {@link Source source content} as the input.
     * This is a shorthand equivalent to:
     * <pre>
     *     new InvertMask(10, new Source(true))
     * </pre>
     */
    public InvertMask() {
        this(10, new Source(true));
    }

    /**
     * Constructs a new {@code InvertMask} effect with the given pad value.
     *
     * @param pad the amount of padding on each side of the resulting image
     * @param input the single input {@code Effect}
     * @throws IllegalArgumentException if {@code pad} is negative, or
     * if {@code input} is null
     */
    public InvertMask(int pad, Effect input) {
        super(input);
        setPad(pad);
    }
    
    /**
     * Returns the input for this {@code Effect}.
     * 
     * @return the input for this {@code Effect}
     */
    public final Effect getInput() {
        return getInputs().get(0);
    }
    
    /**
     * Sets the input for this {@code Effect}.
     * 
     * @param input the input for this {@code Effect}
     * @throws IllegalArgumentException if {@code input} is null
     */
    public void setInput(Effect input) {
        setInput(0, input);
    }
    
    /**
     * Returns the amount of padding added to each side of the resulting
     * image, in pixels.
     * 
     * @return the amount of padding, in pixels
     */
    public int getPad() {
        return pad;
    }
    
    /**
     * Sets the amount of padding added to each side of the resulting
     * image, in pixels.
     * <pre>
     *       Min: 0
     *       Max: Integer.MAX_VALUE
     *   Default: 0
     *  Identity: 0
     * </pre>
     * 
     * @param pad the amount of padding, in pixels
     * @throws IllegalArgumentException if {@code pad} is negative
     */
    public void setPad(int pad) {
        if (pad < 0) {
            throw new IllegalArgumentException("Pad value must be non-negative");
        }
        int old = this.pad;
        this.pad = pad;
        firePropertyChange("pad", old, pad);
    }
    
    @Override
    public Rectangle2D getBounds() {
        Rectangle2D r = getInputs().get(0).getBounds();
        int pad2 = 2*pad;
        r.setFrame(r.getX()-pad, r.getY()-pad, r.getWidth()+pad2, r.getHeight()+pad2);
        return r;
    }
    
    @Override
    public Image filter(GraphicsConfiguration config) {
        Rectangle fullBounds = getBounds().getBounds();
        int w = fullBounds.width;
        int h = fullBounds.height;
        Image dst = getCompatibleImage(config, w, h);

        Effect input = getInputs().get(0);
        Rectangle inputBounds = input.getBounds().getBounds();
        Image src = input.filter(config);

        int iw = inputBounds.width;
        int ih = inputBounds.height;
        int dx = pad;
        int dy = pad;
        int sx = 0;
        int sy = 0;
                
        Graphics2D gdst = (Graphics2D)dst.getGraphics();
        gdst.setColor(Color.WHITE);
        gdst.fillRect(0, 0, w, h);
        gdst.setComposite(AlphaComposite.DstOut);
        gdst.drawImage(src, dx, dy, dx+iw, dy+ih, sx, sy, sx+iw, sx+ih, null);
        gdst.dispose();
        
        return dst;
    }
    
    @Override
    public AccelType getAccelType(GraphicsConfiguration config) {
        // TODO: not sure what to return here...
        return AccelType.NONE;
    }
}
