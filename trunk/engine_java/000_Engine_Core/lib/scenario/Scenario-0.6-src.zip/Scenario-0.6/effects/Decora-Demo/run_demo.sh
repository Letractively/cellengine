#!/bin/sh

usage() {
  echo $1
  echo "Usage: run_demo.sh [-l|[vm params] (-nod3d|-ogl|-trace|-count|-t0-t4|-d0-d4) <DemoName>]"
  echo "  -l         : list demos"
  echo "  <DemoName> : name of the demo to run as listed with -l"
  echo "  [vm params]: list of parameters to pass to the vm"
  echo "  -nod3d     : disable D3D pipeline"
  echo "  -ogl       : enable OpenGL pipeline"
  echo "  -trace     : enable Java2D graphics primitive tracing"
  echo "  -count     : enable Java2D graphics primitive count"
  echo "  -t0..-t4   : enable Java2D native tracing with appropriate level"
  echo "  -d0..-d4   : enable Decora native tracing with appropriate level"
  echo "Example 1: $0 -ogl GaussianBlurTest"
  echo "Example 2: $0 -nod3d -t3 -d4 GlowTest"
}

if [ ! -d src/decora/demo ]; then
  usage "Error: must be run from the Decora-Demo directory."
  exit 1
fi

if [ "$1" = "-l" ]; then
  DEMOS=`cd src/decora/demo; ls -1 *Test.java | sed 's/.java//g;'`
  echo "List of demos:"
  for d in $DEMOS; do
    echo "  "$d
  done
  exit 0
fi

if [ "$1" = "-h" -o "$1" = "" ]; then
  usage "Help Page:"
  exit 0
fi

LIB_PATH="../Decora-D3D-Native/dist;./tools/jogl"
PARAMS=$@
DEMO_NAME=`echo $PARAMS | awk '{print $NF}'`
ORIG_PARAMS=`echo ${PARAMS} | awk '{ for (i = 1; i < NF; i++) {printf "%s ", $i;} }'`
DEMO_CLASS=decora.demo.$DEMO_NAME

VM_PARAMS=
for p in ${ORIG_PARAMS}; do
  case "$p" in
  -nod3d) VM_PARAMS="${VM_PARAMS} -Dsun.java2d.d3d=false" ;;
  -ogl)   VM_PARAMS="${VM_PARAMS} -Dsun.java2d.opengl=True" ;;
  -trace) VM_PARAMS="${VM_PARAMS} -Dsun.java2d.trace=log" ;;
  -count) VM_PARAMS="${VM_PARAMS} -Dsun.java2d.trace=count" ;;
  -t0) J2D_TRACE_LEVEL=0; export J2D_TRACE_LEVEL ;;
  -t1) J2D_TRACE_LEVEL=1; export J2D_TRACE_LEVEL ;;
  -t2) J2D_TRACE_LEVEL=2; export J2D_TRACE_LEVEL ;;
  -t3) J2D_TRACE_LEVEL=3; export J2D_TRACE_LEVEL ;;
  -t4) J2D_TRACE_LEVEL=4; export J2D_TRACE_LEVEL ;;
  -d0) DEC_TRACE_LEVEL=0; export DEC_TRACE_LEVEL ;;
  -d1) DEC_TRACE_LEVEL=1; export DEC_TRACE_LEVEL ;;
  -d2) DEC_TRACE_LEVEL=2; export DEC_TRACE_LEVEL ;;
  -d3) DEC_TRACE_LEVEL=3; export DEC_TRACE_LEVEL ;;
  -d4) DEC_TRACE_LEVEL=4; export DEC_TRACE_LEVEL ;;
  *)      VM_PARAMS="${VM_PARAMS} $p" ;;
  esac
done

echo "Running with params/tracing:"
echo "vm parameters =" ${VM_PARAMS}
env | grep TRACE_LEVEL

if [ ! -f src/decora/demo/${DEMO_NAME}.java ]; then
  usage "Error: No such demo: src/decora/demo/${DEMO_NAME}.java"
  exit 1
fi

if [ "${JAVA_HOME}" != "" ]; then
  if [ ! -f ${JAVA_HOME}/bin/java ]; then
    echo "Error: no java in path and could not find JAVA_HOME=${JAVA_HOME}"
    echo "Set JAVA_HOME to point to your java home dir or set path to java"
    exit 1
  fi
  JAVA_EX=${JAVA_HOME}/bin/java
else  
  which java >/dev/null 2>&1
  if [ $? -eq 0 ]; then
    JAVA_EX=java
  else
    echo "Error: no java in path or JAVA_HOME"
    exit 1
  fi
fi

echo "Using java=${JAVA_EX} (alter with JAVA_HOME env. variable or path)"
${JAVA_EX} -showversion ${VM_PARAMS} -Djava.library.path="${LIB_PATH}" \
  -cp "dist/Decora-Demo.jar;../Decora-Runtime/dist/Decora-Runtime.jar;\
../Decora-HW/dist/Decora-HW.jar;../Decora-D3D/dist/Decora-D3D.jar;\
../Decora-OGL/dist/Decora-OGL.jar;tools/jogl/jogl.jar;tools/jogl/gluegen-rt.jar" \
  ${DEMO_CLASS}
