/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect;

import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.geom.Rectangle2D;

/**
 * An effect that shifts each pixel according to an (x,y) distance from
 * the (red,green) channels of a map image, respectively.
 * 
 * @author Chris Campbell
 */
public class DisplacementMap extends CoreEffect {

    /**
     * Constructs a new {@code DisplacementMap} effect,
     * using the {@link Source source content} as the input.
     * This is a shorthand equivalent to:
     * <pre>
     *     new DisplacementMap(mapInput, new Source(true))
     * </pre>
     * 
     * @throws IllegalArgumentException if {@code mapInput} is null
     */
    public DisplacementMap(Effect mapInput) {
        this(mapInput, new Source(true));
    }

    /**
     * Constructs a new {@code DisplacementMap} effect.
     * 
     * @param mapInput the map input {@code Effect}
     * @param contentInput the content input {@code Effect}
     * @throws IllegalArgumentException if either {@code mapInput} or
     * {@code contentInput} is null
     */
    public DisplacementMap(Effect mapInput, Effect contentInput) {
        super(mapInput, contentInput);
        updatePeerKey("DisplacementMap");
    }
    
    /**
     * Returns the map input for this {@code Effect}.
     * 
     * @return the map input for this {@code Effect}
     */
    public final Effect getMapInput() {
        return getInputs().get(0);
    }
    
    /**
     * Sets the map input for this {@code Effect}.
     * 
     * @param mapInput the map input for this {@code Effect}
     * @throws IllegalArgumentException if {@code mapInput} is null
     */
    public void setMapInput(Effect mapInput) {
        setInput(0, mapInput);
    }
    
    /**
     * Returns the content input for this {@code Effect}.
     * 
     * @return the content input for this {@code Effect}
     */
    public final Effect getContentInput() {
        return getInputs().get(1);
    }
    
    /**
     * Sets the content input for this {@code Effect}.
     * 
     * @param contentInput the content input for this {@code Effect}
     * @throws IllegalArgumentException if {@code contentInput} is null
     */
    public void setContentInput(Effect contentInput) {
        setInput(1, contentInput);
    }
    
    @Override
    public Rectangle2D getBounds() {
        // resulting bounds are the size of the content input bounds
        // (from input 1); the map input (from input 0) needs to be
        // positioned accordingly
        return getContentInput().getBounds();
    }
    
    @Override
    public Image filter(GraphicsConfiguration config) {
        return filterInputs(config, true, 0, 1).getImage();
    }
}
