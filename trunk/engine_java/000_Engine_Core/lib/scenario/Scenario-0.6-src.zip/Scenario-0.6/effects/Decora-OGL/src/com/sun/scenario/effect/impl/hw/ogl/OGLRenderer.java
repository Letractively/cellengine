/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw.ogl;

import com.sun.scenario.effect.impl.hw.HWRenderer;
import com.sun.scenario.effect.impl.hw.Shader;
import java.awt.GraphicsConfiguration;
import java.io.InputStream;
import java.util.Map;
import javax.media.opengl.GL;
import javax.media.opengl.GLContext;
import javax.media.opengl.GLDrawableFactory;
import javax.media.opengl.glu.GLU;
import static javax.media.opengl.GL.*;
import sun.java2d.opengl.OGLSurfaceData;
import sun.java2d.pipe.hw.AccelSurface;

/**
 * @author Chris Campbell
 */
public class OGLRenderer extends HWRenderer {

    private GLU glu = new GLU();
    private GLContext j2dContext;

    public OGLRenderer(GraphicsConfiguration config) {
        super(config);
        // TODO: this is a hack that primes some Java2D/JOGL bridge stuff
        // that needs to happen off the QFT (otherwise we would deadlock
        // when calling createExternalGLContext() below in enable(), which
        // is called on the QFT)
        com.sun.opengl.impl.Java2D.getShareContext(config);
    }
    
    @Override
    public void enable() {
        if (j2dContext == null) {
            j2dContext = GLDrawableFactory.getFactory().createExternalGLContext();
        }
        j2dContext.makeCurrent();
    }
    
    @Override
    public void disable() {
        j2dContext.release();
    }

    private static InputStream getStream(String name) {
        return OGLRenderer.class.getResourceAsStream("glsl/" + name + ".glsl");
    }
    
    @Override
    public Shader createShader(String name,
                               Map<String, Integer> samplers,
                               Map<String, Integer> params)
    {
        return OGLShader.create(getStream(name), samplers);
    }
 
    @Override
    public void setBlendMode(BlendMode mode) {
        GL gl = glu.getCurrentGL();

        switch (mode) {
        default:
        case SRC:
            gl.glDisable(GL_BLEND);
            break;
        case ADD:
            gl.glEnable(GL_BLEND);
            gl.glBlendFunc(GL_ONE, GL_ONE);
            break;
        }
    }
    
    @Override
    public void drawTexture(AccelSurface dst,
                            AccelSurface src, boolean linear,
                            float dx1, float dy1, float dx2, float dy2,
                            float tx1, float ty1, float tx2, float ty2)
    {
        GL gl = glu.getCurrentGL();

        OGLSurfaceData oglSrc = (OGLSurfaceData) src;
        int target = oglSrc.getTextureTarget();
        int texid = oglSrc.getTextureID();

        gl.glEnable(target);
        gl.glBindTexture(target, texid);
        
        // TODO: save/restore these instead of overwriting them...
        int filter = linear ? GL_LINEAR : GL_NEAREST;
        gl.glTexParameteri(target, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        gl.glTexParameteri(target, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        gl.glTexParameteri(target, GL_TEXTURE_MIN_FILTER, filter);
        gl.glTexParameteri(target, GL_TEXTURE_MAG_FILTER, filter);

        gl.glBegin(GL.GL_QUADS);
        gl.glColor4f(1f, 1f, 1f, 1f);
        gl.glTexCoord2f(tx1, ty1); gl.glVertex2f(dx1, dy1);
        gl.glTexCoord2f(tx2, ty1); gl.glVertex2f(dx2, dy1);
        gl.glTexCoord2f(tx2, ty2); gl.glVertex2f(dx2, dy2);
        gl.glTexCoord2f(tx1, ty2); gl.glVertex2f(dx1, dy2);
        gl.glEnd();
        
        gl.glBindTexture(target, 0);
        gl.glDisable(target);
    }
    
    @Override
    public void drawTexture(AccelSurface dst,
                            AccelSurface src1, boolean linear1,
                            AccelSurface src2, boolean linear2,
                            float dx1, float dy1, float dx2, float dy2,
                            float t1x1, float t1y1, float t1x2, float t1y2,
                            float t2x1, float t2y1, float t2x2, float t2y2)
    {
        GL gl = glu.getCurrentGL();

        OGLSurfaceData oglSrc1 = (OGLSurfaceData)src1;
        int target1 = oglSrc1.getTextureTarget();
        int texid1 = oglSrc1.getTextureID();

        OGLSurfaceData oglSrc2 = (OGLSurfaceData)src2;
        int target2 = oglSrc2.getTextureTarget();
        int texid2 = oglSrc2.getTextureID();

        gl.glActiveTexture(GL_TEXTURE0);
        gl.glEnable(target1);
        gl.glBindTexture(target1, texid1);
        
        // TODO: save/restore these instead of overwriting them...
        int filter1 = linear1 ? GL_LINEAR : GL_NEAREST;
        gl.glTexParameteri(target1, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        gl.glTexParameteri(target1, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        gl.glTexParameteri(target1, GL_TEXTURE_MIN_FILTER, filter1);
        gl.glTexParameteri(target1, GL_TEXTURE_MAG_FILTER, filter1);

        gl.glActiveTexture(GL_TEXTURE1);
        gl.glEnable(target2);
        gl.glBindTexture(target2, texid2);

        // TODO: save/restore these instead of overwriting them...
        int filter2 = linear2 ? GL_LINEAR : GL_NEAREST;
        gl.glTexParameteri(target2, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        gl.glTexParameteri(target2, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        gl.glTexParameteri(target2, GL_TEXTURE_MIN_FILTER, filter2);
        gl.glTexParameteri(target2, GL_TEXTURE_MAG_FILTER, filter2);

        gl.glBegin(GL.GL_QUADS);
        gl.glColor4f(1f, 1f, 1f, 1f);
        gl.glMultiTexCoord2f(GL_TEXTURE0, t1x1, t1y1);
        gl.glMultiTexCoord2f(GL_TEXTURE1, t2x1, t2y1);
        gl.glVertex2f(dx1, dy1);
        gl.glMultiTexCoord2f(GL_TEXTURE0, t1x2, t1y1);
        gl.glMultiTexCoord2f(GL_TEXTURE1, t2x2, t2y1);
        gl.glVertex2f(dx2, dy1);
        gl.glMultiTexCoord2f(GL_TEXTURE0, t1x2, t1y2);
        gl.glMultiTexCoord2f(GL_TEXTURE1, t2x2, t2y2);
        gl.glVertex2f(dx2, dy2);
        gl.glMultiTexCoord2f(GL_TEXTURE0, t1x1, t1y2);
        gl.glMultiTexCoord2f(GL_TEXTURE1, t2x1, t2y2);
        gl.glVertex2f(dx1, dy2);
        gl.glEnd();

        gl.glActiveTexture(GL_TEXTURE1);
        gl.glBindTexture(target2, 0);
        gl.glDisable(target2);
        
        gl.glActiveTexture(GL_TEXTURE0);
        gl.glBindTexture(target1, 0);
        gl.glDisable(target1);
    }
}
