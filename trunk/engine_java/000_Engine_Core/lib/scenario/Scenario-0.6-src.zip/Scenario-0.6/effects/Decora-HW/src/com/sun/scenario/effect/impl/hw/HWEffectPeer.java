/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw;

import com.sun.scenario.effect.Effect;
import com.sun.scenario.effect.Effect.AccelType;
import com.sun.scenario.effect.impl.EffectPeer;
import com.sun.scenario.effect.impl.ImageData;
import java.awt.GraphicsConfiguration;
import java.awt.image.VolatileImage;
import java.lang.reflect.Constructor;
import java.security.AccessController;
import java.security.PrivilegedAction;
import sun.java2d.pipe.hw.AccelGraphicsConfig;
import sun.java2d.pipe.hw.ContextCapabilities;

/**
 * @author Chris Campbell
 */
public abstract class HWEffectPeer extends EffectPeer {

    protected HWEffectPeer(GraphicsConfiguration gc) {
        super(gc);
    }
    
    private static String getHwPrefix(GraphicsConfiguration gc) {
        String gcName = gc.getClass().getSimpleName();
        if (gcName.startsWith("WGL") || gcName.startsWith("GLX")) {
            return rootPkg + ".impl.hw.ogl.OGL";
        } else if (gcName.startsWith("D3D")) {
            return rootPkg + ".impl.hw.d3d.D3D";
        } else {
            return null;
        }
    }

    /**
     * Returns true if the current hardware meets the minimum requirements
     * (i.e., availability of Pixel Shader 3.0 level hardware).
     * 
     * @return true if the current hardware is valid, false otherwise
     */
    private static boolean isHwValid(final GraphicsConfiguration gc) {
        return AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
            public Boolean run() {
                if (gc instanceof AccelGraphicsConfig) {
                    AccelGraphicsConfig agc = (AccelGraphicsConfig)gc;
                    int caps = agc.getContextCapabilities().getCaps();
                    return ((caps & ContextCapabilities.CAPS_PS30) != 0);
                }
                return false;
            }
        });
    }
    
    /**
     * Creates a new HWRenderer (either OGL or D3D) depending on the type
     *  of the given GraphicsConfiguration.  The EffectPeer base
     * class maintains a cache of Renderers (one per GraphicsConfig), so
     * it should be the only one using this method.  To obtain an instance
     * of a Renderer from the cache, the framework should instead call
     * the EffectPeer.getRenderer() method.
     */
    public static HWRenderer createRenderer(GraphicsConfiguration gc) {
        String prefix = getHwPrefix(gc);
        if (prefix == null) {
            //System.err.println("Renderer name not found for pipeline");
            return null;
        }

        if (!isHwValid(gc)) {
            return null;
        }

        Class klass = null;
        try {
            klass = Class.forName(prefix + "Renderer");
        } catch (ClassNotFoundException e) {
            System.err.println(prefix + "Renderer class not found");
            return null;
        } catch (Throwable t) {
            //System.err.println("Error loading renderer:");
            //t.printStackTrace();
            return null;
        }
        try {
            Constructor ctor = klass.getConstructor(GraphicsConfiguration.class);
            return (HWRenderer)ctor.newInstance(gc);
        } catch (Exception e) {
            System.err.println("Error instantiating " + klass.getName() + ":");
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public final ImageData filter(final Effect effect, final ImageData... inputs) {
        // doPrivileged() is required here because we are accessing
        // sun.* classes directly
        return AccessController.doPrivileged(new PrivilegedAction<ImageData>() {
            public ImageData run() {
                return filterImpl(effect, inputs);
            }
        });
    }
    
    abstract ImageData filterImpl(Effect effect, ImageData... inputs);

    protected abstract boolean isSamplerLinear(int i);
    
    protected abstract Shader createShader();
    
    protected abstract void updateShader(Shader shader);

    @Override
    protected final HWRenderer getRenderer() {
        return (HWRenderer)super.getRenderer();
    }
    
    protected VolatileImage getDestImageFromPool(int w, int h) {
        return (VolatileImage)getRenderer().getCompatibleImage(w, h);
    }

    @Override
    public AccelType getAccelType() {
        if (getRenderer().getClass().getSimpleName().startsWith("OGL")) {
            return AccelType.OPENGL;
        } else {
            return AccelType.DIRECT3D;
        }
    }
}
