/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package decora.demo;

import com.sun.scenario.effect.Effect;
import com.sun.scenario.effect.PerspectiveTransform;
import com.sun.scenario.effect.SourceContent;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

/**
 * @author Flar
 */
public class PerspectiveTest extends AbstractDemo {

    private static final float R = 5f;
    private static final int grabRadius = 20;
    private PerspectiveTransform perspective;
    private int dx = 120;
    private int dy = 120;
    private Ellipse2D[] pts = new Ellipse2D[4];
    private int selIndex = -1;
    private Point2D selPrev;

    public PerspectiveTest() {
        setBackground(Color.black);
        setRenderOffset(0, 0);
        Image img = makeTextImage("Decora!");
        int imgw = img.getWidth(null);
        int imgh = img.getHeight(null);
        this.perspective = new PerspectiveTransform();
        this.perspective.setSourceContent(new SourceContent(img, new Rectangle(dx, dy, imgw, imgh)));
        setPreferredSize(new Dimension(800, 500));
        
        initPoint(0, dx, dy);
        initPoint(1, dx + imgw, dy);
        initPoint(2, dx + imgw, dy + imgh);
        initPoint(3, dx, dy + imgh);
        updateTransform();
        
        MouseAdapter l = new HandleListener();
        addMouseListener(l);
        addMouseMotionListener(l);
    }

    private void initPoint(int index, float cx, float cy) {
        pts[index] = new Ellipse2D.Float(cx-R, cy-R, R*2, R*2);
    }

    private void updateTransform() {
        float x0 = (float) pts[0].getCenterX();
        float y0 = (float) pts[0].getCenterY();
        float x1 = (float) pts[1].getCenterX();
        float y1 = (float) pts[1].getCenterY();
        float x2 = (float) pts[2].getCenterX();
        float y2 = (float) pts[2].getCenterY();
        float x3 = (float) pts[3].getCenterX();
        float y3 = (float) pts[3].getCenterY();
        perspective.setQuadMapping(x0, y0, x1, y1, x2, y2, x3, y3);
    }
    
    private class HandleListener extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            Point p = e.getPoint();
            double closestdistsq = grabRadius*grabRadius;
            for (int i = 0; i < 4; i++) {
                double dx = pts[i].getCenterX() - p.getX();
                double dy = pts[i].getCenterY() - p.getY();
                double distsq = dx*dx + dy*dy;
                if (closestdistsq > distsq) {
                    closestdistsq = distsq;
                    selIndex = i;
                    selPrev = p;
                }
            }
        }
        
        @Override
        public void mouseDragged(MouseEvent e) {
            Point p = e.getPoint();
            if (selPrev != null) {
                double x = pts[selIndex].getX() + p.getX() - selPrev.getX();
                double y = pts[selIndex].getY() + p.getY() - selPrev.getY();
                selPrev = p;
                pts[selIndex].setFrame(x, y, R*2, R*2);
                updateTransform();
                repaint();
            }
        }
        
        @Override
        public void mouseReleased(MouseEvent e) {
            if (selPrev != null) {
                selIndex = -1;
                selPrev = null;
                repaint();
            }
        }
    }
  
    @Override
    Image makeTextImage(String text) {
        // TODO: ideally we'd use the panel's GraphicsConfig, but that isn't
        // available until the frame has been made visible...
        //GraphicsConfiguration gc = getGraphicsConfiguration();
        GraphicsConfiguration gc =
            GraphicsEnvironment.getLocalGraphicsEnvironment().
            getDefaultScreenDevice().getDefaultConfiguration();
        Image src = Effect.createCompatibleImage(gc, 550, 200);
        Graphics2D gimg = (Graphics2D)src.getGraphics();
        gimg.setColor(Color.WHITE);
        //gimg.setComposite(AlphaComposite.Clear);
        gimg.fillRect(0, 0, 550, 200);
        gimg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                              RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        gimg.setComposite(AlphaComposite.SrcOver);
        gimg.setColor(Color.RED);
        gimg.setFont(new Font("SansSerif", Font.BOLD, 120));
        gimg.drawString(text, 20, 140);
        gimg.dispose();
        return src;
    }
    
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        for (int i = 0; i < 4; i++) {
            g2.setColor(i == selIndex ? Color.RED : Color.GREEN);
            g2.draw(pts[i]);
        }
    }

    @Override
    PerspectiveTransform getEffect() {
        return perspective;
    }

    public static void main(String[] args) {
        launch(PerspectiveTest.class);
    }
}
