/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw.d3d;

import com.sun.scenario.effect.impl.BufferUtil;
import com.sun.scenario.effect.impl.hw.Shader;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Map;

/**
 * @author Chris Campbell
 */
public class D3DShader implements Shader {

    private static IntBuffer itmp;
    private static FloatBuffer ftmp;
    private long pData;
    private final Map<String, Integer> registers;

    public D3DShader(long pd3dr,
                     ByteBuffer buf, Map<String, Integer> registers)
    {
        this.pData = init(pd3dr, buf);
        this.registers = registers;
    }

    private static native long init(long pd3dd, ByteBuffer buf);

    private static native void enable(long pData);

    public void enable() {
        enable(pData);
    }

    private static native void disable(long pData);

    public void disable() {
        disable(pData);
    }

    private static void checkTmpIntBuf() {
        if (itmp == null) {
            itmp = BufferUtil.newIntBuffer(4);
        }
        itmp.clear();
    }

    public void setConstant(String name, int i0) {
        // TODO: see HLSLBackend for an explanation of why we're using
        // floats here instead of ints...
        /*
        checkTmpIntBuf();
        itmp.put(i0);
        setConstants(name, itmp, 0, 1);
         */
        setConstant(name, (float)i0);
    }

    public void setConstant(String name, int i0, int i1) {
        /*
        checkTmpIntBuf();
        itmp.put(i0);
        itmp.put(i1);
        setConstants(name, itmp, 0, 1);
         */
        setConstant(name, (float)i0, (float)i1);
    }

    public void setConstant(String name, int i0, int i1, int i2) {
        /*
        checkTmpIntBuf();
        itmp.put(i0);
        itmp.put(i1);
        itmp.put(i2);
        setConstants(name, itmp, 0, 1);
         */
        setConstant(name, (float)i0, (float)i1, (float)i2);
    }

    public void setConstant(String name, int i0, int i1, int i2, int i3) {
        /*
        checkTmpIntBuf();
        itmp.put(i0);
        itmp.put(i1);
        itmp.put(i2);
        itmp.put(i3);
        setConstants(name, itmp, 0, 1);
         */
        setConstant(name, (float)i0, (float)i1, (float)i2, (float)i3);
    }

    public void setConstants(String name, IntBuffer buf, int off, int count) {
        // TODO: bounds checking
        //setConstantsI(pData, getRegister(name), buf, off, count);
        // TODO: see HLSLBackend for an explanation of why we need to use
        // floats instead of ints; for now this codepath is disabled...
        throw new InternalError("Not yet implemented");
    }

    private static native void setConstantsI(long pData, int register,
                                                IntBuffer buf, int off,
                                                int count);

    private static void checkTmpFloatBuf() {
        if (ftmp == null) {
            ftmp = BufferUtil.newFloatBuffer(4);
        }
        ftmp.clear();
    }

    public void setConstant(String name, float f0) {
        checkTmpFloatBuf();
        ftmp.put(f0);
        setConstants(name, ftmp, 0, 1);
    }

    public void setConstant(String name, float f0, float f1) {
        checkTmpFloatBuf();
        ftmp.put(f0);
        ftmp.put(f1);
        setConstants(name, ftmp, 0, 1);
    }

    public void setConstant(String name, float f0, float f1, float f2) {
        checkTmpFloatBuf();
        ftmp.put(f0);
        ftmp.put(f1);
        ftmp.put(f2);
        setConstants(name, ftmp, 0, 1);
    }

    public void setConstant(String name, float f0, float f1, float f2, float f3) {
        checkTmpFloatBuf();
        ftmp.put(f0);
        ftmp.put(f1);
        ftmp.put(f2);
        ftmp.put(f3);
        setConstants(name, ftmp, 0, 1);
    }

    public void setConstants(String name, FloatBuffer buf, int off, int count) {
        // TODO: bounds checking
        setConstantsF(pData, getRegister(name), buf, off, count);
    }

    private static native void setConstantsF(long pData, int register,
                                                FloatBuffer buf, int off,
                                                int count);

    private int getRegister(String name) {
        Integer reg = registers.get(name);
        if (reg == null) {
            throw new IllegalArgumentException("Register not found for: " +
                                               name);
        }
        return reg;
    }
}
