/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

#ifndef _D3DVB_H
#define	_D3DVB_H

#include "D3DDecora.h"

#define DEF_MAX_VERT_NUM 256
#define APPEND_ACTION 0x0
#define RESET_ACTION  0x1
#define D3DFVF_DCRLVERTEX \
    (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX2 | \
    D3DFVF_TEXCOORDSIZE2(0) | D3DFVF_TEXCOORDSIZE2(1) )
typedef struct _J2DLVERTEX {
    float x, y, z;
    DWORD color;
    float tu1, tv1;
    float tu2, tv2;
} J2DLVERTEX;

const D3DVERTEXELEMENT9 VDecl[5] = {
    { 0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
    { 0, 12, D3DDECLTYPE_D3DCOLOR, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR,    0 },
    { 0, 16, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
    { 0, 24, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 1 },
    D3DDECL_END()
};

class D3DVB {
public:
    HRESULT Init(IDirect3DDevice9 *pd3dDevice);
            ~D3DVB() { ReleaseDefPoolResources(); }
    void    ReleaseDefPoolResources();

    jint    GetColor() { return color; }
    void    SetColor(jint newColor) { color = newColor; }
    HRESULT DrawTexture(float dx1, float dy1, float dx2, float dy2,
                        float tx1, float ty1, float tx2, float ty2);
    HRESULT DrawTexture(float  dx1, float  dy1, float  dx2, float  dy2,
                        float t1x1, float t1y1, float t1x2, float t1y2,
                        float t2x1, float t2y1, float t2x2, float t2y2);

    HRESULT Render(int actionType = APPEND_ACTION);
    
    HRESULT CheckVB(IDirect3DDevice9 *pd3dDevice);
    HRESULT RestoreVB(IDirect3DDevice9 *pd3dDevice);

static
    HRESULT CreateInstance(IDirect3DDevice9 *pd3dDevice, D3DVB **ppVC);

private:
            D3DVB();
    HRESULT EnsureCapacity();

private:
    UINT                    firstPendingVertex;
    UINT                    firstUnusedVertex;
    UINT                    numOfTriangles;
    UINT                    maxNumOfVertices;
    J2DLVERTEX              *pVertices;
    IDirect3DVertexBuffer9  *lpD3DVertexBuffer;
    IDirect3DVertexBuffer9  *lpSavedVB;
    IDirect3DDevice9        *lpD3DDevice;
    jint                    color;
    
};

#define ADD_VERTEX_XYUVC(X, Y, U1, V1, VCOLOR) \
do { \
    pVertices[firstUnusedVertex].x = (X); \
    pVertices[firstUnusedVertex].y = (Y); \
    pVertices[firstUnusedVertex].z = 0.0f; \
    pVertices[firstUnusedVertex].tu1 = (U1); \
    pVertices[firstUnusedVertex].tv1 = (V1); \
    pVertices[firstUnusedVertex].color = (DWORD)(VCOLOR); \
    firstUnusedVertex++; \
} while (0)

#define ADD_VERTEX_XYUVUVC(X, Y, U1, V1, U2, V2, VCOLOR) \
do { \
    pVertices[firstUnusedVertex].tu2 = (U2); \
    pVertices[firstUnusedVertex].tv2 = (V2); \
    ADD_VERTEX_XYUVC(X, Y, U1, V1, VCOLOR); \
} while (0)

#define ADD_TRIANGLE_XYUVC(X1, Y1, X2, Y2, X3, Y3,         \
                           U1, V1, U2, V2, U3, V3, VCOLOR) \
do { \
    ADD_VERTEX_XYUVC(X1, Y1, U1, V1, VCOLOR); \
    ADD_VERTEX_XYUVC(X2, Y2, U2, V2, VCOLOR); \
    ADD_VERTEX_XYUVC(X3, Y3, U3, V3, VCOLOR); \
    numOfTriangles++;   \
} while (0)

#define ADD_TRIANGLE_XYUVUVC(X1, Y1, X2, Y2, X3, Y3,       \
                             U11, V11, U12, V12, U13, V13, \
                             U21, V21, U22, V22, U23, V23, \
                             VCOLOR)                       \
do { \
    ADD_VERTEX_XYUVUVC(X1, Y1, U11, V11, U21, V21, VCOLOR); \
    ADD_VERTEX_XYUVUVC(X2, Y2, U12, V12, U22, V22, VCOLOR); \
    ADD_VERTEX_XYUVUVC(X3, Y3, U13, V13, U23, V23, VCOLOR); \
    numOfTriangles++;   \
} while (0)

#endif	/* _D3DVB_H */

