/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw;

import com.sun.scenario.effect.impl.Renderer;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Transparency;
import java.awt.image.VolatileImage;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Map;
import sun.java2d.pipe.hw.AccelGraphicsConfig;
import sun.java2d.pipe.hw.AccelSurface;

/**
 * @author Chris Campbell
 */
public abstract class HWRenderer extends Renderer {

    protected final GraphicsConfiguration config;
    
    protected HWRenderer(GraphicsConfiguration config) {
        this.config = config;
    }

    public abstract void enable();
    
    public abstract void disable();
    
    public abstract Shader createShader(String name,
                               Map<String, Integer> samplers,
                               Map<String, Integer> params);
    
    public enum BlendMode { SRC, ADD }
    public abstract void setBlendMode(BlendMode mode);
    
    public abstract void drawTexture(AccelSurface dst,
                            AccelSurface src, boolean linear,
                            float dx1, float dy1, float dx2, float dy2,
                            float tx1, float ty1, float tx2, float ty2);
    
    public abstract void drawTexture(AccelSurface dst,
                            AccelSurface src1, boolean linear1,
                            AccelSurface src2, boolean linear2,
                            float dx1, float dy1, float dx2, float dy2,
                            float t1x1, float t1y1, float t1x2, float t1y2,
                            float t2x1, float t2y1, float t2x2, float t2y2);
    
    @Override
    public final VolatileImage createCompatibleImage(final int w, final int h) {
        return AccessController.doPrivileged(new PrivilegedAction<VolatileImage>() {
            public VolatileImage run() {
                AccelGraphicsConfig agc = (AccelGraphicsConfig)config;
                VolatileImage vi = null;
                // TODO: temp. workaround for jdk bug 6667607
                try {
                    vi = agc.createCompatibleVolatileImage(w, h,
                        Transparency.TRANSLUCENT,
                        AccelSurface.RT_TEXTURE);
                } catch (NullPointerException e) {}

                if (vi != null) {
                    vi.validate(config);
                    Graphics2D g2 = vi.createGraphics();
                    g2.setComposite(AlphaComposite.Clear);
                    g2.fillRect(0, 0, w, h);
                    g2.dispose();
                }
                return vi;
            }
        });
    }
}
