/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw;

import com.sun.scenario.effect.Effect;
import com.sun.scenario.effect.impl.ImageData;
import java.awt.GraphicsConfiguration;
import java.awt.Rectangle;
import java.awt.image.VolatileImage;
import sun.java2d.DestSurfaceProvider;
import sun.java2d.pipe.BufferedContext;
import sun.java2d.pipe.RenderQueue;
import sun.java2d.pipe.hw.AccelSurface;

/**
 * @author Chris Campbell
 */
public abstract class HWOneInputPeer extends HWEffectPeer {
    
    private Shader shader;

    protected HWOneInputPeer(GraphicsConfiguration gc) {
        super(gc);
    }
    
    @Override
    ImageData filterImpl(Effect effect, ImageData... inputs) {
        setEffect(effect);
        
        VolatileImage src = (VolatileImage)inputs[0].getImage();
        Rectangle srcBounds = inputs[0].getBounds();
        Rectangle dstBounds = getDestBounds();
        final int dstw = dstBounds.width;
        final int dsth = dstBounds.height;
        
        VolatileImage dst = getDestImageFromPool(dstw, dsth);
        dst.validate(getGraphicsConfig()); // TODO: check return value
        
        if (dst instanceof DestSurfaceProvider) {
            DestSurfaceProvider ssrc = (DestSurfaceProvider)src;
            DestSurfaceProvider sdst = (DestSurfaceProvider)dst;
            final AccelSurface srcData = (AccelSurface)ssrc.getDestSurface();
            final AccelSurface dstData = (AccelSurface)sdst.getDestSurface();

            setInputBounds(0, srcBounds);
            setInputNativeBounds(0, srcData.getNativeBounds());
            final float[] srcRect = getSourceRegion(0);

            RenderQueue rq = dstData.getContext().getRenderQueue();
            rq.lock();
            try {
                dstData.getContext().saveState();
                BufferedContext.validateContext(dstData);
                rq.flushAndInvokeNow(new Runnable() {
                    public void run() {
                        HWRenderer renderer = getRenderer();
                        renderer.enable();
                        if (shader == null) {
                            shader = createShader();
                        }
                        shader.enable();
                        updateShader(shader);
                        if (!dstData.isSurfaceLost()) {
                            float dx1 = 0;
                            float dy1 = 0;
                            float dx2 = dstw;
                            float dy2 = dsth;
                            float tx1 = srcRect[0];
                            float ty1 = srcRect[1];
                            float tx2 = srcRect[2];
                            float ty2 = srcRect[3];

                            renderer.drawTexture(dstData,
                                                 srcData, isSamplerLinear(0),
                                                 dx1, dy1, dx2, dy2,
                                                 tx1, ty1, tx2, ty2);
                        }
                        shader.disable();
                        renderer.disable();
                    }
                });
                dstData.getContext().restoreState();
            } finally {
                rq.unlock();
            }
        }
        
        return new ImageData(dst, dstBounds);
    }
}
