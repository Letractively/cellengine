/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.compiler.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static com.sun.scenario.effect.compiler.model.Type.*;

/**
 * Maintains the sets of core (built-in) functions and variables.
 * 
 * @author Chris Campbell
 */
public class CoreSymbols {

    private static Set<Variable> vars = new HashSet<Variable>();
    private static Set<Function> funcs = new HashSet<Function>();

    static Set<Variable> getAllVariables() {
        return vars;
    }
    
    static Set<Function> getAllFunctions() {
        return funcs;
    }
    
    public static Function getFunction(String name, List<Type> ptypes) {
        return SymbolTable.getFunctionForSignature(funcs, name, ptypes);
    }
    
    static {
        // pos0/1 and pixcoord are declared "const" (read-only) to prevent
        // accidental assignment
        declareVariable("pos0", FLOAT2, true);
        declareVariable("pos1", FLOAT2, true);
        declareVariable("pixcoord", FLOAT2, true);
        declareVariable("color", FLOAT4, false);
        
        // float4 sample(sampler s, float2 loc)
        declareFunction(FLOAT4, "sample", SAMPLER, "s", FLOAT2, "loc");

        // float4 sample(lsampler s, float2 loc)
        declareFunction(FLOAT4, "sample", LSAMPLER, "s", FLOAT2, "loc");

        // <ftype> min(<ftype> x, <ftype> y)
        // <ftype> min(<ftype> x, float y)
        declareOverloadsMinMax("min");

        // <ftype> max(<ftype> x, <ftype> y)
        // <ftype> max(<ftype> x, float y)
        declareOverloadsMinMax("max");

        // <ftype> clamp(<ftype> val, <ftype> min, <ftype> max)
        // <ftype> clamp(<ftype> val, float min, float max)
        declareOverloadsClamp();

        // <ftype> abs(<ftype> x)
        declareOverloadsSimple("abs");

        // <ftype> floor(<ftype> x)
        declareOverloadsSimple("floor");

        // <ftype> ceil(<ftype> x)
        declareOverloadsSimple("ceil");

        // <ftype> sign(<ftype> x)
        declareOverloadsSimple("sign");

        // <ftype> sqrt(<ftype> x)
        declareOverloadsSimple("sqrt");

        // <ftype> sin(<ftype> x)
        declareOverloadsSimple("sin");

        // <ftype> cos(<ftype> x)
        declareOverloadsSimple("cos");

        // <ftype> tan(<ftype> x)
        declareOverloadsSimple("tan");

        // <ftype> pow(<ftype> x, <ftype> y)
        // <ftype> pow(<ftype> x, float y)
        declareOverloadsMinMax("pow");

        // float dot(<ftype> x, <ftype> y)
        declareOverloadsFloat2("dot");

        // <ftype> mix(<ftype> x, <ftype> y, <ftype> a)
        // <ftype> mix(<ftype> x, <ftype> y, float a)
        declareOverloadsMix();
        
        // <ftype> normalize(<ftype> x)
        declareOverloadsSimple("normalize");
    }

    private static void declareVariable(String name, Type type, boolean readonly) {
        Qualifier qual = readonly ? Qualifier.CONST : null;
        vars.add(new Variable(name, type, qual, -1, -1, null, false));
    }
    
    private static void declareFunction(Type returnType,
                                        String name,
                                        Object... params)
    {
        List<Param> paramList = new ArrayList<Param>();
        if (params.length % 2 != 0) {
            throw new InternalError("Params array length must be even");
        }
        for (int i = 0; i < params.length; i+=2) {
            if (!(params[i+0] instanceof Type) ||
                !(params[i+1] instanceof String))
            {
                throw new InternalError("Params must be specified as (Type,String) pairs");
            }
            paramList.add(new Param((String)params[i+1], (Type)params[i]));
        }
        funcs.add(new Function(name, returnType, paramList));
    }
    
    private static void declareOverloadsSimple(String name) {
        declareFunction(FLOAT,  name, FLOAT,  "x");
        declareFunction(FLOAT2, name, FLOAT2, "x");
        declareFunction(FLOAT3, name, FLOAT3, "x");
        declareFunction(FLOAT4, name, FLOAT4, "x");
    }
    
    private static void declareOverloadsMinMax(String name) {
        declareFunction(FLOAT,  name, FLOAT,  "x", FLOAT,  "y");
        declareFunction(FLOAT2, name, FLOAT2, "x", FLOAT2, "y");
        declareFunction(FLOAT3, name, FLOAT3, "x", FLOAT3, "y");
        declareFunction(FLOAT4, name, FLOAT4, "x", FLOAT4, "y");
        declareFunction(FLOAT2, name, FLOAT2, "x", FLOAT,  "y");
        declareFunction(FLOAT3, name, FLOAT3, "x", FLOAT,  "y");
        declareFunction(FLOAT4, name, FLOAT4, "x", FLOAT,  "y");
    }

    private static void declareOverloadsClamp() {
        final String name = "clamp";
        declareFunction(FLOAT,  name, FLOAT,  "val", FLOAT,  "min", FLOAT,  "max");
        declareFunction(FLOAT2, name, FLOAT2, "val", FLOAT2, "min", FLOAT2, "max");
        declareFunction(FLOAT3, name, FLOAT3, "val", FLOAT3, "min", FLOAT3, "max");
        declareFunction(FLOAT4, name, FLOAT4, "val", FLOAT4, "min", FLOAT4, "max");
        declareFunction(FLOAT2, name, FLOAT2, "val", FLOAT,  "min", FLOAT,  "max");
        declareFunction(FLOAT3, name, FLOAT3, "val", FLOAT,  "min", FLOAT,  "max");
        declareFunction(FLOAT4, name, FLOAT4, "val", FLOAT,  "min", FLOAT,  "max");
    }

    private static void declareOverloadsMix() {
        final String name = "mix";
        declareFunction(FLOAT,  name, FLOAT,  "x", FLOAT,  "y", FLOAT,  "a");
        declareFunction(FLOAT2, name, FLOAT2, "x", FLOAT2, "y", FLOAT2, "a");
        declareFunction(FLOAT3, name, FLOAT3, "x", FLOAT3, "y", FLOAT3, "a");
        declareFunction(FLOAT4, name, FLOAT4, "x", FLOAT4, "y", FLOAT4, "a");
        declareFunction(FLOAT2, name, FLOAT2, "x", FLOAT2, "y", FLOAT,  "a");
        declareFunction(FLOAT3, name, FLOAT3, "x", FLOAT3, "y", FLOAT,  "a");
        declareFunction(FLOAT4, name, FLOAT4, "x", FLOAT4, "y", FLOAT,  "a");
    }

    private static void declareOverloadsFloat2(String name) {
        declareFunction(FLOAT, name, FLOAT,  "x", FLOAT,  "y");
        declareFunction(FLOAT, name, FLOAT2, "x", FLOAT2, "y");
        declareFunction(FLOAT, name, FLOAT3, "x", FLOAT3, "y");
        declareFunction(FLOAT, name, FLOAT4, "x", FLOAT4, "y");
    }
}
