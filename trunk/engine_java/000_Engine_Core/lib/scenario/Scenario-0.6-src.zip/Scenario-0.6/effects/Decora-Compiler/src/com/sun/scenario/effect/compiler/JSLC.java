/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.compiler;

import com.sun.scenario.effect.compiler.backend.JavaBackend;
import com.sun.scenario.effect.compiler.backend.HLSLBackend;
import com.sun.scenario.effect.compiler.backend.GLSLBackend;
import com.sun.scenario.effect.compiler.tree.ProgramUnit;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import org.antlr.runtime.ANTLRInputStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.stringtemplate.CommonGroupLoader;
import org.antlr.stringtemplate.StringTemplateGroup;
import static com.sun.scenario.effect.compiler.model.Type.*;

/**
 * @author Chris Campbell
 */
public class JSLC {

    public static final int OUT_NONE = (0 << 0);
    public static final int OUT_OGL  = (1 << 0);
    public static final int OUT_D3D  = (1 << 1);
    public static final int OUT_JAVA = (1 << 2);
    public static final int OUT_HW   = OUT_OGL | OUT_D3D;
    public static final int OUT_ALL  = OUT_JAVA | OUT_HW;

    private static String rootPkg = "com/sun/scenario/effect";
    private static String rootDir = null;
    
    static {
        CommonGroupLoader loader = new CommonGroupLoader(rootPkg + "/compiler/backend", null);
        StringTemplateGroup.registerGroupLoader(loader);
    }
    
    /**
     * If rootDir is provided by the user, then we will output all files
     * under that directory, for example if rootDir=/foo/bar:
     *   /foo/bar/ + rootPkg + /impl/sw
     *   /foo/bar/ + rootPkg + /impl/hw
     *   /foo/bar/ + rootPkg + /impl/hw/ogl/glsl
     *   /foo/bar/ + rootPkg + /impl/hw/d3d/hlsl
     * 
     * Otherwise, we use the layout currently expected by Decora-Runtime
     * for core effects:
     *   ../Decora-Runtime/build/gensrc/ + rootPkg + /impl/sw
     *   ../Decora-HW/build/gensrc/      + rootPkg + /impl/hw
     *   ../Decora-OGL/build/gensrc/     + rootPkg + /impl/hw/ogl/glsl
     *   ../Decora-D3D/build/gensrc/     + rootPkg + /impl/hw/d3d/hlsl
     */
    private static String getRoot(String type) {
        if (rootDir != null) {
            return rootDir + "/" + rootPkg;
        } else {
            return "../Decora-" + type + "/build/gensrc/" + rootPkg;
        }
    }
    
    public static void setRootDir(String dir) {
        rootDir = dir;
    }

    public static void compile(String str,
                               String effectName, String peerName,
                               int outTypes)
        throws Exception
    {
        compile(new ByteArrayInputStream(str.getBytes()),
                effectName, peerName, outTypes);
    }

    public static void compile(File file,
                               String effectName, String peerName,
                               int outTypes)
        throws Exception
    {
        compile(new FileInputStream(file),
                effectName, peerName, outTypes);
    }
    
    private static void compile(File file, String name, int outTypes)
        throws Exception
    {
        compile(new FileInputStream(file), name, name, outTypes);
    }
    
    private static void compile(InputStream stream,
                                String effectName, String peerName,
                                int outTypes)
        throws Exception
    {
        // Read input
        ANTLRInputStream input = new ANTLRInputStream(stream);

        // Lexer
        JSLLexer lexer = new JSLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        // Parser and AST construction
        JSLParser parser = new JSLParser(tokens);
        ProgramUnit program = parser.translation_unit();

        // Compiler
        if ((outTypes & OUT_OGL) != 0) {
            GLSLBackend glslBackend = new GLSLBackend(parser, program);

            // write shader
            File glslDir = new File(getRoot("OGL") + "/impl/hw/ogl/glsl");
            if (!glslDir.exists()) {
                glslDir.mkdirs();
            }
            File glslFile = new File(glslDir, peerName + ".glsl");
            write(glslBackend.getShader(), glslFile);

            // write glue class
            writeHWGlue(peerName, glslBackend.getGlueCode(effectName, peerName));
        }

        if ((outTypes & OUT_D3D) != 0) {
            HLSLBackend hlslBackend = new HLSLBackend(parser, program);

            // write shader
            File hlslDir = new File(getRoot("D3D") + "/impl/hw/d3d/hlsl");
            if (!hlslDir.exists()) {
                hlslDir.mkdirs();
            }
            File hlslFile = new File(hlslDir, peerName + ".hlsl");
            write(hlslBackend.getShader(), hlslFile);

            // write glue class
            if ((outTypes & OUT_OGL) == 0) {
                writeHWGlue(peerName, hlslBackend.getGlueCode(effectName, peerName));
            }
        }
        
        if ((outTypes & OUT_JAVA) != 0) {
            JavaBackend javaBackend = new JavaBackend(parser, program);

            // write impl class
            File genDir = new File(getRoot("Runtime") + "/impl/sw");
            if (!genDir.exists()) {
                genDir.mkdirs();
            }
            File genFile = new File(genDir, "SW" + peerName + "Peer.java");
            write(javaBackend.getGenCode(effectName, peerName), genFile);
        }
    }
    
    private static void writeHWGlue(String name, String body) throws Exception {
        File glueDir = new File(getRoot("HW") + "/impl/hw");
        if (!glueDir.exists()) {
            glueDir.mkdirs();
        }
        File glueFile = new File(glueDir, "HW" + name + "Peer.java");
        write(body, glueFile);
    }
    
    private static void write(String str, File outFile) throws Exception {
        FileWriter fw = null;
        try {
            fw = new FileWriter(outFile);
            fw.write(str);
            fw.flush();
        } finally {
            if (fw != null) {
                fw.close();
            }
        }
    }
    
    private static void usage() {
        System.out.println("Usage: jslc [-d3d | -ogl | -java | -all] [-o <rootdir>] [-name <name>] <inputfile>");
    }
    
    public static void main(String[] args) throws Exception {
        File inFile = null;
        String name = null;
        int outTypes = OUT_NONE;
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.equals("-d3d")) {
                outTypes |= OUT_D3D;
            } else if (arg.equals("-ogl")) {
                outTypes |= OUT_OGL;
            } else if (arg.equals("-java")) {
                outTypes |= OUT_JAVA;
            } else if (arg.equals("-all")) {
                outTypes = OUT_ALL;
            } else if (arg.equals("-o")) {
                if (i >= args.length-1) {
                    usage();
                }
                rootDir = args[++i];
            } else if (arg.equals("-name")) {
                if (i >= args.length-1) {
                    usage();
                }
                name = args[++i];
            } else if (arg.equals("-help")) {
                usage();
            } else {
                inFile = new File(arg);
                if (!inFile.exists()) {
                    System.err.println("Input file not found");
                    System.exit(1);
                }
                if (!arg.endsWith(".jsl") || arg.length() < 5) {
                    System.err.println("Input file name must end with '.jsl'");
                    System.exit(1);
                }
            }
        }
        
        if (inFile == null) {
            System.err.println("Must specify one input file");
            usage();
            System.exit(1);
        }
        
        if (name == null) {
            String s = inFile.getName();
            name = s.substring(0, s.length()-4);
        }
        
        compile(inFile, name, outTypes);
    }
}
