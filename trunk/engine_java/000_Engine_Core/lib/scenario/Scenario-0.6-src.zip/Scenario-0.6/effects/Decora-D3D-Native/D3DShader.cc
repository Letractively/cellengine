/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

#include "D3DShader.h"
#include "D3DRenderer.h"
#include "com_sun_scenario_effect_impl_hw_d3d_D3DShader.h"

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DShader_init
  (JNIEnv *env, jclass klass,
   jlong pd3dr, jobject bbuf)
{
    D3DRenderer *pd3dRnd;
    IDirect3DPixelShader9 *pShader;
    IDirect3DDevice9 *pd3dDevice;

    TraceLn(DEC_TRACE_INFO, "D3DShader_init");

    DWORD *buf = (DWORD *)env->GetDirectBufferAddress(bbuf);
    if (buf == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get direct buffer address");
        return 0L;
    }

    pd3dRnd = (D3DRenderer*)jlong_to_ptr(pd3dr);
    RETURN_STATUS_IF_NULL(pd3dRnd, 0L);

    pd3dDevice = pd3dRnd->GetDevice();
    RETURN_STATUS_IF_NULL(pd3dDevice, 0L);

    if (FAILED(pd3dDevice->CreatePixelShader(buf, &pShader))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Error creating shader");
        return 0L;
    }

    return ptr_to_jlong(pShader);
}

JNIEXPORT void JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DShader_enable
  (JNIEnv *env, jclass klass,
   jlong pData)
{
    TraceLn(DEC_TRACE_INFO, "D3DShader_enable");

    IDirect3DPixelShader9 *pShader = (IDirect3DPixelShader9 *)jlong_to_ptr(pData);
    if (pShader == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  pShader is null");
        return;
    }

    IDirect3DDevice9 *pd3dDevice;
    if (FAILED(pShader->GetDevice(&pd3dDevice))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get device from shader");
        return;
    }

    if (FAILED(pd3dDevice->SetPixelShader(pShader))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  SetPixelShader failed");
    }
    pd3dDevice->Release();
}

JNIEXPORT void JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DShader_disable
  (JNIEnv *env, jclass klass,
   jlong pData)
{
    TraceLn(DEC_TRACE_INFO, "D3DShader_disable");

    IDirect3DPixelShader9 *pShader = (IDirect3DPixelShader9 *)jlong_to_ptr(pData);
    if (pShader == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  pShader is null");
        return;
    }

    IDirect3DDevice9 *pd3dDevice;
    if (FAILED(pShader->GetDevice(&pd3dDevice))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get device from shader");
        return;
    }

    pd3dDevice->SetPixelShader(NULL);
    pd3dDevice->Release();
}

JNIEXPORT void JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DShader_setConstantsI
  (JNIEnv *env, jclass klass,
   jlong pData, jint reg, jobject ibuf, jint off, jint count)
{
    TraceLn3(DEC_TRACE_INFO, "D3DShader_setConstantsI (reg=%d, off=%d, count=%d)", reg, off, count);

    IDirect3DPixelShader9 *pShader = (IDirect3DPixelShader9 *)jlong_to_ptr(pData);
    if (pShader == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  pShader is null");
        return;
    }

    IDirect3DDevice9 *pd3dDevice;
    if (FAILED(pShader->GetDevice(&pd3dDevice))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get device from shader");
        return;
    }

    jint *buf = (jint *)env->GetDirectBufferAddress(ibuf);
    if (buf == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get direct buffer address");
        SAFE_RELEASE(pd3dDevice);
        return;
    }

    buf += off * sizeof(jint);

    if (FAILED(pd3dDevice->SetPixelShaderConstantI(reg, (const int *)buf, count))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  SetPixelShaderConstantI failed");
    }
    SAFE_RELEASE(pd3dDevice);
}

JNIEXPORT void JNICALL
Java_com_sun_scenario_effect_impl_hw_d3d_D3DShader_setConstantsF
  (JNIEnv *env, jclass klass,
   jlong pData, jint reg, jobject fbuf, jint off, jint count)
{
    TraceLn3(DEC_TRACE_INFO, "D3DShader_setConstantsF (reg=%d, off=%d, count=%d)", reg, off, count);

    IDirect3DPixelShader9 *pShader = (IDirect3DPixelShader9 *)jlong_to_ptr(pData);
    if (pShader == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  pShader is null");
        return;
    }

    IDirect3DDevice9 *pd3dDevice;
    if (FAILED(pShader->GetDevice(&pd3dDevice))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get device from shader");
        return;
    }

    jfloat *buf = (jfloat *)env->GetDirectBufferAddress(fbuf);
    if (buf == NULL) {
        RlsTraceLn(DEC_TRACE_ERROR, "  Could not get direct buffer address");
        SAFE_RELEASE(pd3dDevice);
        return;
    }

    buf += off * sizeof(jfloat);

    TraceLn4(DEC_TRACE_VERBOSE, "  vals: %f %f %f %f", buf[0], buf[1], buf[2], buf[3]);

    if (FAILED(pd3dDevice->SetPixelShaderConstantF(reg, (const float *)buf, count))) {
        RlsTraceLn(DEC_TRACE_ERROR, "  SetPixelShaderConstantF failed");
    }
    SAFE_RELEASE(pd3dDevice);
}

}
