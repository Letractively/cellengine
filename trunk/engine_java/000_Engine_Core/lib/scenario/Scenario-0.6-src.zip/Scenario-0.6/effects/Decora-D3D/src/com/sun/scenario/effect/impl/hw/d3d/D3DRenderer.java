/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw.d3d;

import com.sun.scenario.effect.impl.hw.HWRenderer;
import com.sun.scenario.effect.impl.hw.Shader;
import java.awt.GraphicsConfiguration;
import java.awt.Transparency;
import java.awt.image.VolatileImage;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Arrays;
import java.util.Map;
import sun.java2d.DestSurfaceProvider;
import sun.java2d.Surface;
import sun.java2d.pipe.BufferedContext;
import sun.java2d.pipe.RenderQueue;
import sun.java2d.pipe.hw.AccelGraphicsConfig;
import sun.java2d.pipe.hw.AccelSurface;
import static sun.java2d.pipe.hw.AccelSurface.*;
import static sun.java2d.d3d.D3DSurfaceData.*;

/**
 * @author Chris Campbell
 */
public class D3DRenderer extends HWRenderer {

    /**
     * Pointer to the native D3DRenderer class
     */
    private long pd3dr;

    static {
        AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                System.loadLibrary("Decora-D3D");
                return null;
            }
        });
    }

    public D3DRenderer(final GraphicsConfiguration config) {
        super(config);
        AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                pd3dr = init(config);
                return null;
            }
        });
    }

    /**
     * Creates native resources associated with this renderer, and returns
     * a pointer to the native D3DRenderer class.
     *
     * @param pd3dd pointer to IDirect3DDevice9
     * @return pointer to the native D3DRenderer class
     */
    private static native long init(long pd3dd);
    /**
     * Enables the renderer (sets the vertex buffer, vertex shader,
     * begins the scene).
     *
     * @param pd3dr pointer to the native renderer
     * @return HRESULT status of the operation
     */
    private static native long enable(long pd3dr);
    /**
     * Disables the renderer (disables vertex shader, ends the scene).
     *
     * @param pd3dr pointer to the native renderer
     * @return HRESULT status of the operation
     */
    private static native long disable(long pd3dr);
    /**
     * Returns a pointer to the IDirect3DDevice9 associated with this
     * renderer.
     *
     * @param pd3dr pointer to the native renderer
     * @return IDirect3DDevice9 pointer
     */
    private static native long getDevicePtr(long pd3dr);
    /**
     * Disposes the native resources associated with the renderer.
     *
     * @param pd3dr pointer to the native renderer
     */
    private static native void dispose(long pd3dr);

    @Override
    public void enable() {
        // TODO: currently we do BS/ES on each enable/disable, this is
        // not ideal from the performance perspective
        // TODO: error handling
        enable(pd3dr);
    }

    @Override
    public void disable() {
        // TODO: error handling
        disable(pd3dr);
    }

    public void dispose() {
        dispose(pd3dr);
        pd3dr = 0L;
    }

    private long init(GraphicsConfiguration gc) {
        long ret = 0;
        // assert: this must not be run on the RQ thread!

        // TODO: this is a temp. hack since we don't have a way to retrieve
        // a pointer to the direct3d device from a GC. Note that we we can
        // not rely on the pointer to be valid off the RQ thread either.
        if (gc instanceof AccelGraphicsConfig) {
            AccelGraphicsConfig agc = (AccelGraphicsConfig)gc;
            VolatileImage vi =
                agc.createCompatibleVolatileImage(8, 8, Transparency.OPAQUE,
                                                  TEXTURE);
            if (vi instanceof DestSurfaceProvider) {
                vi.validate(gc);
                DestSurfaceProvider p = ((DestSurfaceProvider)vi);
                Surface s = p.getDestSurface();
                if (s instanceof AccelSurface) {
                    final BufferedContext bc = agc.getContext();
                    RenderQueue rq = bc.getRenderQueue();
                    final AccelSurface as = (AccelSurface)s;
                    rq.lock();
                    try {
                        final long ar[] = {0L};
                        rq.flushAndInvokeNow(new Runnable() {
                            public void run() {
                                bc.saveState();
                                long pd3dd =
                                    as.getNativeResource(D3D_DEVICE_RESOURCE);
                                if (pd3dd != 0L) {
                                    ar[0] = init(pd3dd);
                                }
                                bc.restoreState();
                            }
                        });
                        ret = ar[0];
                    } finally {
                        rq.unlock();
                    }
                }
                vi.flush();
                vi = null;
            }
        }
        return ret;
    }

    private static ByteBuffer getBuffer(String name) {
        try {
            InputStream is = D3DRenderer.class.getResourceAsStream("hlsl/" + name + ".obj");
            if (is == null) {
                throw new RuntimeException("D3D shader object not found for " + name);
            }
            int len = 4096;
            byte[] data = new byte[len];
            BufferedInputStream bis = new BufferedInputStream(is, len);
            int offset = 0;
            int readBytes = -1;
            while ((readBytes = bis.read(data, offset, len - offset)) != -1) {
                offset += readBytes;
                if (len - offset == 0) {
                    // grow the array
                    len *= 2;
                    data = Arrays.copyOf(data, len);
                }
            }
            bis.close();
            // TODO: for now the D3DShader native code only knows how to
            // deal with direct ByteBuffers, so we have to dump the byte[]
            // into a newly allocated direct buffer...
            ByteBuffer buf = ByteBuffer.allocateDirect(offset);
            buf.put(data, 0, offset);
            return buf;
        } catch (IOException e) {
            throw new RuntimeException("Error loading D3D shader object", e);
        }
    }

    @Override
    public Shader createShader(String name,
                               Map<String, Integer> samplers,
                               Map<String, Integer> params)
    {
        return new D3DShader(pd3dr, getBuffer(name), params);
    }

    static native void setBlendMode(long pd3dr, int mode);

    @Override
    public void setBlendMode(BlendMode mode) {
        setBlendMode(pd3dr, mode.ordinal());
    }

    static native long drawTexture(long pd3dr,
                                   long pDst, long pSrc, boolean linear,
                                   float dx1, float dy1, float dx2, float dy2,
                                   float tx1, float ty1, float tx2, float ty2);

    @Override
    public void drawTexture(AccelSurface dst,
                            AccelSurface src, boolean linear,
                            float dx1, float dy1, float dx2, float dy2,
                            float tx1, float ty1, float tx2, float ty2)
    {
        drawTexture(pd3dr,
                    dst.getNativeResource(RT_PLAIN),
                    src.getNativeResource(TEXTURE), linear,
                    dx1, dy1, dx2, dy2,
                    tx1, ty1, tx2, ty2);
    }

    static native long drawTexture2(long pd3dr,
                                    long pDst,
                                    long pSrc1, boolean linear1,
                                    long pSrc2, boolean linear2,
                                    float dx1, float dy1, float dx2, float dy2,
                                    float t1x1, float t1y1, float t1x2, float t1y2,
                                    float t2x1, float t2y1, float t2x2, float t2y2);

    @Override
    public void drawTexture(AccelSurface dst,
                            AccelSurface src1, boolean linear1,
                            AccelSurface src2, boolean linear2,
                            float dx1, float dy1, float dx2, float dy2,
                            float t1x1, float t1y1, float t1x2, float t1y2,
                            float t2x1, float t2y1, float t2x2, float t2y2)
    {
        drawTexture2(pd3dr,
                     dst.getNativeResource(RT_PLAIN),
                     src1.getNativeResource(TEXTURE), linear1,
                     src2.getNativeResource(TEXTURE), linear2,
                     dx1, dy1, dx2, dy2,
                     t1x1, t1y1, t1x2, t1y2,
                     t2x1, t2y1, t2x2, t2y2);
    }
}
