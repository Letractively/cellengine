/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.compiler.parser;

import com.sun.scenario.effect.compiler.JSLParser;
import com.sun.scenario.effect.compiler.model.Qualifier;
import com.sun.scenario.effect.compiler.model.SymbolTable;
import com.sun.scenario.effect.compiler.model.Type;
import com.sun.scenario.effect.compiler.tree.BinaryExpr;
import org.antlr.runtime.RecognitionException;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class AssignmentExprTest extends ParserBase {

    @Test
    public void userVar() throws Exception {
        BinaryExpr tree = parseTreeFor("foo = 32.0");
    }

    @Test(expected = RuntimeException.class)
    public void userROVar() throws Exception {
        BinaryExpr tree = parseTreeFor("readonly = 32.0");
    }

    @Test
    public void coreVar() throws Exception {
        BinaryExpr tree = parseTreeFor("color = float4(1.0)");
    }

    @Test
    public void coreVarField() throws Exception {
        BinaryExpr tree = parseTreeFor("color.r = 3.0");
    }

    @Test(expected = RuntimeException.class)
    public void coreROVar() throws Exception {
        BinaryExpr tree = parseTreeFor("pos0 = float2(1.0)");
    }
    
    @Test(expected = RuntimeException.class)
    public void coreROVarField() throws Exception {
        BinaryExpr tree = parseTreeFor("pos0.x = 1.0");
    }

    @Test(expected = RecognitionException.class)
    public void notAnAssignment() throws Exception {
        parseTreeFor("const foo");
    }

    private BinaryExpr parseTreeFor(String text) throws RecognitionException {
        JSLParser parser = parserOver(text);
        SymbolTable st = parser.getSymbolTable();
        st.declareVariable("foo", Type.FLOAT, null);
        st.declareVariable("readonly", Type.FLOAT, Qualifier.CONST);
        return (BinaryExpr)parser.assignment_expression();
    }
}
