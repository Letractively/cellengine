/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package decora.demo;

import com.sun.scenario.effect.PhongLighting;
import com.sun.scenario.effect.Shadow;
import com.sun.scenario.effect.light.DistantLight;
import com.sun.scenario.effect.light.Light;
import com.sun.scenario.effect.light.PointLight;
import com.sun.scenario.effect.light.SpotLight;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Chris Campbell
 */
public class LightControls extends javax.swing.JPanel {
    
    /** Creates new form LightControls */
    public LightControls(final PhongLightingTest test) {
        initComponents();
        
        bumpSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                Shadow shadow = test.getShadowEffect();
                float bump = bumpSlider.getValue();
                shadow.setRadius(bump);
                test.repaint();
            }
        });
        
        azimuthSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                ((DistantLight)phong.getLight()).setAzimuth(azimuthSlider.getValue());
                test.repaint();
            }
        });
        elevationSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                ((DistantLight)phong.getLight()).setElevation(elevationSlider.getValue());
                test.repaint();
            }
        });

        lightXSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light light = phong.getLight();
                if (light instanceof PointLight) {
                    ((PointLight)light).setX(lightXSlider.getValue());
                }
                test.repaint();
            }
        });
        lightYSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light light = phong.getLight();
                if (light instanceof PointLight) {
                    ((PointLight)light).setY(lightYSlider.getValue());
                }
                test.repaint();
            }
        });
        lightZSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light light = phong.getLight();
                if (light instanceof PointLight) {
                    ((PointLight)light).setZ(lightZSlider.getValue());
                }
                test.repaint();
            }
        });

        pointsAtXSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light light = phong.getLight();
                if (light instanceof SpotLight) {
                    ((SpotLight)light).setPointsAtX(pointsAtXSlider.getValue());
                }
                test.repaint();
            }
        });
        pointsAtYSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light light = phong.getLight();
                if (light instanceof SpotLight) {
                    ((SpotLight)light).setPointsAtY(pointsAtYSlider.getValue());
                }
                test.repaint();
            }
        });
        pointsAtZSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light light = phong.getLight();
                if (light instanceof SpotLight) {
                    ((SpotLight)light).setPointsAtZ(pointsAtZSlider.getValue());
                }
                test.repaint();
            }
        });

        scaleSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                float scale = scaleSlider.getValue() / 10f;
                phong.setSurfaceScale(scale);
                test.repaint();
            }
        });
        
        dConSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                float v = dConSlider.getValue() / 100f;
                phong.setDiffuseConstant(v);
                test.repaint();
            }
        });
        
        sConSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                float v = sConSlider.getValue() / 100f;
                phong.setSpecularConstant(v);
                test.repaint();
            }
        });
        
        sExpSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                PhongLighting phong = test.getPhongEffect();
                float v = sExpSlider.getValue() / 10f;
                phong.setSpecularExponent(v);
                test.repaint();
            }
        });
        
        rbDistant.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                PhongLighting phong = test.getPhongEffect();
                Light old = phong.getLight();
                float az = azimuthSlider.getValue();
                float el = elevationSlider.getValue();
                DistantLight dist = new DistantLight(az, el, old.getColor());
                phong.setLight(dist);
                setLocationSlidersEnabled(test);
                test.repaint();
            }
        });

        rbPoint.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                PhongLighting phong = test.getPhongEffect();
                float x = lightXSlider.getValue();
                float y = lightYSlider.getValue();
                float z = lightZSlider.getValue();
                Light old = phong.getLight();
                PointLight point = new PointLight(x, y, z, old.getColor());
                phong.setLight(point);
                setLocationSlidersEnabled(test);
                test.repaint();
            }
        });

        rbSpot.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                PhongLighting phong = test.getPhongEffect();
                float x = lightXSlider.getValue();
                float y = lightYSlider.getValue();
                float z = lightZSlider.getValue();
                Light old = phong.getLight();
                SpotLight spot = new SpotLight(x, y, z, old.getColor());
                phong.setLight(spot);
                setLocationSlidersEnabled(test);
                test.repaint();
            }
        });
    }
    
    private void setLocationSlidersEnabled(PhongLightingTest test) {
        PhongLighting phong = test.getPhongEffect();
        boolean a = false, b = false, c = false;
        switch (phong.getLight().getType()) {
        case DISTANT:
            a = true;
            break;
        case POINT:
            b = true;
            break;
        case SPOT:
            b = true;
            c = true;
            break;
        }
        azimuthSlider.setEnabled(a);
        elevationSlider.setEnabled(a);
        lightXSlider.setEnabled(b);
        lightYSlider.setEnabled(b);
        lightZSlider.setEnabled(b);
        pointsAtXSlider.setEnabled(c);
        pointsAtYSlider.setEnabled(c);
        pointsAtZSlider.setEnabled(c);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        bumpSlider = new javax.swing.JSlider();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lightXSlider = new javax.swing.JSlider();
        lightYSlider = new javax.swing.JSlider();
        lightZSlider = new javax.swing.JSlider();
        jLabel5 = new javax.swing.JLabel();
        scaleSlider = new javax.swing.JSlider();
        dConSlider = new javax.swing.JSlider();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        sConSlider = new javax.swing.JSlider();
        jLabel8 = new javax.swing.JLabel();
        sExpSlider = new javax.swing.JSlider();
        btnReset = new javax.swing.JButton();
        rbDistant = new javax.swing.JRadioButton();
        rbPoint = new javax.swing.JRadioButton();
        rbSpot = new javax.swing.JRadioButton();
        jLabel9 = new javax.swing.JLabel();
        azimuthSlider = new javax.swing.JSlider();
        elevationSlider = new javax.swing.JSlider();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        pointsAtXSlider = new javax.swing.JSlider();
        pointsAtYSlider = new javax.swing.JSlider();
        pointsAtZSlider = new javax.swing.JSlider();

        bumpSlider.setMaximum(63);
        bumpSlider.setMinimum(1);
        bumpSlider.setValue(10);

        jLabel1.setText("Bump:");
        jLabel1.setFocusable(false);

        jLabel2.setText("Light XYZ:");
        jLabel2.setFocusable(false);

        lightXSlider.setMaximum(20000);
        lightXSlider.setMinimum(-20000);
        lightXSlider.setValue(-10000);
        lightXSlider.setEnabled(false);

        lightYSlider.setMaximum(20000);
        lightYSlider.setMinimum(-20000);
        lightYSlider.setValue(-10000);
        lightYSlider.setEnabled(false);

        lightZSlider.setMaximum(40000);
        lightZSlider.setValue(30000);
        lightZSlider.setEnabled(false);

        jLabel5.setText("Surface Scale:");
        jLabel5.setFocusable(false);

        dConSlider.setMaximum(200);
        dConSlider.setValue(100);

        jLabel6.setText("Diffuse Constant:");
        jLabel6.setFocusable(false);

        jLabel7.setText("Specular Constant:");
        jLabel7.setFocusable(false);

        sConSlider.setMaximum(200);
        sConSlider.setValue(75);

        jLabel8.setText("Specular Exponent:");
        jLabel8.setFocusable(false);

        sExpSlider.setMaximum(400);
        sExpSlider.setValue(200);

        btnReset.setText("Reset All");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbDistant);
        rbDistant.setSelected(true);
        rbDistant.setText("Distant");

        buttonGroup1.add(rbPoint);
        rbPoint.setText("Point");

        buttonGroup1.add(rbSpot);
        rbSpot.setText("Spot");

        jLabel9.setText("Azimuth:");
        jLabel9.setFocusable(false);

        azimuthSlider.setMaximum(180);
        azimuthSlider.setMinimum(-180);
        azimuthSlider.setValue(-135);

        elevationSlider.setMaximum(180);
        elevationSlider.setMinimum(-180);
        elevationSlider.setValue(45);

        jLabel10.setText("Elevation:");
        jLabel10.setFocusable(false);

        jLabel11.setText("Points At XYZ:");
        jLabel11.setFocusable(false);

        pointsAtXSlider.setMaximum(20000);
        pointsAtXSlider.setMinimum(-20000);
        pointsAtXSlider.setValue(10000);
        pointsAtXSlider.setEnabled(false);

        pointsAtYSlider.setMaximum(20000);
        pointsAtYSlider.setMinimum(-20000);
        pointsAtYSlider.setValue(10000);
        pointsAtYSlider.setEnabled(false);

        pointsAtZSlider.setMaximum(40000);
        pointsAtZSlider.setValue(10000);
        pointsAtZSlider.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sConSlider, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                            .addComponent(sExpSlider, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                            .addComponent(dConSlider, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                            .addComponent(scaleSlider, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(rbDistant)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbPoint)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbSpot)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 263, Short.MAX_VALUE)
                        .addComponent(btnReset)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGap(6, 6, 6))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lightXSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pointsAtXSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pointsAtYSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
                    .addComponent(lightYSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lightZSlider, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pointsAtZSlider, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(bumpSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(azimuthSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(elevationSlider, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(bumpSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(azimuthSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(elevationSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lightZSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lightYSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lightXSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pointsAtZSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pointsAtYSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pointsAtXSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(scaleSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(dConSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(sConSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(sExpSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rbSpot)
                        .addComponent(rbPoint)
                        .addComponent(rbDistant))
                    .addComponent(btnReset))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
         rbDistant.setSelected(true);
         bumpSlider.setValue(10);
         lightXSlider.setValue(-10000);
         lightYSlider.setValue(-10000);
         lightZSlider.setValue(30000);
         pointsAtXSlider.setValue(10000);
         pointsAtYSlider.setValue(10000);
         pointsAtZSlider.setValue(10000);
         azimuthSlider.setValue(-135);
         elevationSlider.setValue(45);
         scaleSlider.setValue(50);
         dConSlider.setValue(100);
         sConSlider.setValue(75);
         sExpSlider.setValue(200);
}//GEN-LAST:event_btnResetActionPerformed
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSlider azimuthSlider;
    private javax.swing.JButton btnReset;
    private javax.swing.JSlider bumpSlider;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JSlider dConSlider;
    private javax.swing.JSlider elevationSlider;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSlider lightXSlider;
    private javax.swing.JSlider lightYSlider;
    private javax.swing.JSlider lightZSlider;
    private javax.swing.JSlider pointsAtXSlider;
    private javax.swing.JSlider pointsAtYSlider;
    private javax.swing.JSlider pointsAtZSlider;
    private javax.swing.JRadioButton rbDistant;
    private javax.swing.JRadioButton rbPoint;
    private javax.swing.JRadioButton rbSpot;
    private javax.swing.JSlider sConSlider;
    private javax.swing.JSlider sExpSlider;
    private javax.swing.JSlider scaleSlider;
    // End of variables declaration//GEN-END:variables
    
}
