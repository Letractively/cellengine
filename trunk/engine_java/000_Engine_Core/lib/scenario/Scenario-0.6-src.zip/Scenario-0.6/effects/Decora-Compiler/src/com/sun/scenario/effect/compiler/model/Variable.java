/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.compiler.model;

/**
 * @author Chris Campbell
 */
public class Variable {

    private final String name;
    private final Type type;
    private final Qualifier qual;
    private final int reg;
    private final int arraySize;
    private final Object constValue;
    private final boolean isParam;

    Variable(String name, Type type) {
        this(name, type, null, -1, -1, null, false);
    }
    
    Variable(String name, Type type, Qualifier qual, int reg,
             int arraySize, Object constValue, boolean isParam)
    {
        if (name == null) {
            throw new IllegalArgumentException("Name must be non-null");
        }
        if (type == null) {
            throw new IllegalArgumentException("Type must be non-null");
        }
        this.name = name;
        this.type = type;
        this.qual = qual;
        this.reg = reg;
        this.arraySize = arraySize;
        this.constValue = constValue;
        this.isParam = isParam;
    }

    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }
    
    public Qualifier getQualifier() {
        return qual;
    }

    public int getReg() {
        return reg;
    }
    
    public boolean isArray() {
        return arraySize > 0;
    }
    
    public int getArraySize() {
        return arraySize;
    }
    
    public Object getConstValue() {
        return constValue;
    }
    
    public boolean isParam() {
        return isParam;
    }
}
