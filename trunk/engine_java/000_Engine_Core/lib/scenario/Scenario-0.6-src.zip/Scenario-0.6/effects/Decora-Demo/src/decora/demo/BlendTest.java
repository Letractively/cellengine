/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package decora.demo;

import com.sun.scenario.effect.Blend;
import com.sun.scenario.effect.Identity;
import com.sun.scenario.effect.SourceContent;
import com.sun.scenario.effect.Source;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Chris Campbell
 */
public class BlendTest extends AbstractDemo {

    private Blend blend;

    public BlendTest() {
        Identity bot = new Identity(loadImage("resources/water.jpg"));
        Source top = new Source(true);
        this.blend = new Blend(Blend.Mode.SRC_OVER, bot, top);
        this.blend.setSourceContent(new SourceContent(makeSrcImage("resources/train.jpg")));
        this.blend.setOpacity(0.5f);
        setPreferredSize(new Dimension(540, 400));
    }
    
    @Override
    Blend getEffect() {
        return blend;
    }
    
    void setMode(Blend.Mode mode) {
        blend.setMode(mode);
        repaint();
    }
    
    void setOpacity(float t) {
        blend.setOpacity(t);
        repaint();
    }

    private static class EnumComboBoxModel<E extends Enum<E>>
        extends AbstractListModel
        implements ComboBoxModel
    {
        private E selected = null;
        private List<E> list;

        public EnumComboBoxModel(Class<E> en) {
            EnumSet<E> ens = EnumSet.allOf(en);
            list = new ArrayList<E>(ens);
            selected = list.get(0);
        }

        public int getSize() {
            return list.size();
        }

        public E getElementAt(int index) {
            return list.get(index);
        }

        public void setSelectedItem(Object anItem) {
            selected = (E)anItem;
            this.fireContentsChanged(this, 0, getSize());
        }
    
        public E getSelectedItem() {
            return selected;
        }
    }

    @Override
    protected void installControlPanels(JPanel panel) {
        final JSlider slider = new JSlider(0, 100, 50);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                JSlider slider = (JSlider) e.getSource();
                float opacity = slider.getValue() / 100.0f;
                setOpacity(opacity);
            }
        });
        final JComboBox combo = new JComboBox();
        combo.setModel(new EnumComboBoxModel(Blend.Mode.class));
        combo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMode((Blend.Mode)combo.getSelectedItem());
            }
        });
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEADING));
        controls.add(new JLabel("Opacity: 0.0"));
        controls.add(slider);
        controls.add(new JLabel("1.0"));
        controls.add(new JLabel("Mode:"));
        controls.add(combo);
        panel.add(controls, BorderLayout.SOUTH);
    }
    
    public static void main(String[] args) {
        launch(BlendTest.class);
    }
}
