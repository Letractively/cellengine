/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.sw;

import com.sun.scenario.effect.Effect.AccelType;
import com.sun.scenario.effect.impl.EffectPeer;
import java.awt.GraphicsConfiguration;
import java.awt.image.BufferedImage;

/**
 * @author Chris Campbell
 */
public abstract class SWEffectPeer extends EffectPeer {

    protected SWEffectPeer(GraphicsConfiguration gc) {
        super(gc);
    }
    
    protected BufferedImage getDestImageFromPool(int w, int h) {
        return (BufferedImage)getRenderer().getCompatibleImage(w, h);
    }

    @Override
    public AccelType getAccelType() {
        return AccelType.NONE;
    }

    protected final void accum(int pixel, float mul, float fvals[]) {
        mul /= 255f;
        fvals[0] += ((pixel >>  16) & 0xff) * mul;
        fvals[1] += ((pixel >>   8) & 0xff) * mul;
        fvals[2] += ((pixel       ) & 0xff) * mul;
        fvals[3] += ((pixel >>> 24)       ) * mul;
    }

    protected final void lsample(int img[],
                                 float floc_x, float floc_y,
                                 int w, int h, int scan,
                                 float fvals[])
    {
        fvals[0] = 0f;
        fvals[1] = 0f;
        fvals[2] = 0f;
        fvals[3] = 0f;
        if (floc_x >= 0 && floc_y >= 0 && floc_x < 1 && floc_y < 1) {
            // If we subtract 0.5 then floc_xy could go negative and the
            // integer cast will not perform a true floor operation so
            // instead we add 0.5 and then iloc_xy will be off by 1
            floc_x = floc_x * w + 0.5f;
            floc_y = floc_y * h + 0.5f;
            int iloc_x = (int) floc_x;  // 0 <= iloc_x <= w
            int iloc_y = (int) floc_y;  // 0 <= iloc_y <= h
            floc_x -= iloc_x;   // now fractx
            floc_y -= iloc_y;   // now fracty
            // sample box from iloc_x-1,y-1 to iloc_x,y
            int offset = iloc_y * scan + iloc_x;
            float fract = floc_x * floc_y;
            if (iloc_y < h) {
                if (iloc_x < w) {
                    accum(img[offset], fract, fvals);
                }
                if (iloc_x > 0) {
                    accum(img[offset-1], floc_y - fract, fvals);
                }
            }
            if (iloc_y > 0) {
                if (iloc_x < w) {
                    accum(img[offset-scan], floc_x - fract, fvals);
                }
                if (iloc_x > 0) {
                    accum(img[offset-scan-1], 1f - floc_x - floc_y + fract, fvals);
                }
            }
        }
    }
}
