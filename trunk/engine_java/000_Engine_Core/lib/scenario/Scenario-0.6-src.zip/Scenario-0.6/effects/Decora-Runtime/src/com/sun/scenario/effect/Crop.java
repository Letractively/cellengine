/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

/**
 * An effect that returns a cropped version of the input.
 * 
 * @author Chris Campbell
 */
public class Crop extends Effect {
    
    /**
     * Constructs a new {@code Crop} effect,
     * using the {@link Source source content} as the input.
     * This is a shorthand equivalent to:
     * <pre>
     *     new Crop(new Source(true))
     * </pre>
     */
    public Crop() {
        this(new Source(true));
    }

    /**
     * Constructs a new {@code Crop} effect.
     *
     * @param input the single input {@code Effect}
     * @throws IllegalArgumentException if {@code input} is null
     */
    public Crop(Effect input) {
        // TODO: for now we will just crop to the source bounds; later
        // we need to allow the user to control the crop region
        super(input);
    }
    
    /**
     * Returns the input for this {@code Effect}.
     * 
     * @return the input for this {@code Effect}
     */
    public final Effect getInput() {
        return getInputs().get(0);
    }
    
    /**
     * Sets the input for this {@code Effect}.
     * 
     * @param input the input for this {@code Effect}
     * @throws IllegalArgumentException if {@code input} is null
     */
    public void setInput(Effect input) {
        setInput(0, input);
    }
    
    @Override
    public Rectangle2D getBounds() {
        Rectangle2D r = new Rectangle2D.Float();
        if (getInputs().get(0).isInDeviceSpace()) {
            r.setRect(getSourceContent().getTransformedBounds());
        } else {
            r.setRect(getSourceContent().getUntransformedBounds());
        }
        return r;
    }
    
    @Override
    public Image filter(GraphicsConfiguration config) {
        Rectangle fullBounds = getBounds().getBounds();
        int w = fullBounds.width;
        int h = fullBounds.height;
        Image dst = getCompatibleImage(config, w, h);

        Effect input = getInputs().get(0);
        Rectangle inputBounds = input.getBounds().getBounds();
        Image src = input.filter(config);

        int dx = 0;
        int dy = 0;
        int sx = fullBounds.x - inputBounds.x;
        int sy = fullBounds.y - inputBounds.y;
                
        Graphics2D gdst = (Graphics2D)dst.getGraphics();
        gdst.setComposite(AlphaComposite.Src);
        gdst.drawImage(src, dx, dy, dx+w, dy+h, sx, sy, sx+w, sx+h, null);
        gdst.dispose();
        
        return dst;
    }
    
    @Override
    public AccelType getAccelType(GraphicsConfiguration config) {
        // TODO: not sure what to return here...
        return AccelType.NONE;
    }
}
