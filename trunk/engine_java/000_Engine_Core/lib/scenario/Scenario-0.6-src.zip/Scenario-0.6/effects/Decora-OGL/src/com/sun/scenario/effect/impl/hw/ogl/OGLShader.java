/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.impl.hw.ogl;

import com.sun.scenario.effect.impl.hw.Shader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Map;
import javax.media.opengl.GL;
import javax.media.opengl.GLException;
import javax.media.opengl.glu.GLU;
import static javax.media.opengl.GL.*;

/**
 * Represents an OpenGL shader program object, which can be constructed from
 * the source code for a vertex shader, a fragment shader, or both.
 * Contains convenience methods for enabling/disabling shader state.
 * <p>
 * Usage example:
 * <pre>
 *     String source =
 *         "uniform sampler2D myTex;" +
 *         "void main(void)" +
 *         "{" +
 *         "    vec4 src = texture2D(myTex, gl_TexCoord[0].st);" +
 *         "    gl_FragColor = src.bgra;" + // swizzle!
 *         "}";
 *     OGLShader shader = new OGLShader(source);
 *     shader.setConstant("myTex", 0); // myTex will be on texture unit 0
 *     ...
 *     shader.enable();
 *     texture.enable();
 *     texture.bind();
 *     ...
 *     texture.disable();
 *     shader.disable();
 * };
 * </pre>
 *
 * @author Chris Campbell
 */
public class OGLShader implements Shader {
    
    /**
     * The handle to the OpenGL fragment program object.
     */
    private int id;
    
    /**
     * Creates a new shader program object and compiles/links the provided
     * fragment shader code into that object.
     * 
     * @param fragmentCode a {@code String} representing the fragment shader
     * source code to be compiled and linked
     * 
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public OGLShader(String fragmentCode, Map<String, Integer> samplers)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        this.id = createProgram(gl, null, fragmentCode);
        
        if (samplers != null) {
            enable();
            for (String key : samplers.keySet()) {
                setConstant(key, samplers.get(key));
            }
            disable();
        }
    }
    
    // TODO: remove this later
    public static OGLShader create(InputStream in) {
        return create(in, null);
    }
    
    public static OGLShader create(InputStream in, Map<String, Integer> samplers) {
        return new OGLShader(readStream(in), samplers);
    }
    
    static String readStream(InputStream in) {
        StringBuffer sb = new StringBuffer(1024);
	BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        try {
            char[] chars = new char[1024];
            int numRead = 0;
            while ((numRead = reader.read(chars)) > -1) {
                sb.append(String.valueOf(chars, 0, numRead));
            }
        } catch (IOException e) {
            System.err.println("Error reading stream");
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                System.err.println("Error closing reader");
            }
        }
	return sb.toString();
    }
    
    /**
     * Compiles and links a new shader program using the given sources.  If
     * successful, this function returns a handle to the newly created shader
     * program; otherwise returns 0.
     * 
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    private static int createProgram(GL gl,
                                     String vertexShaderSource,
                                     String fragmentShaderSource)
        throws GLException
    {
        if (vertexShaderSource == null && fragmentShaderSource == null) {
            throw new GLException(
                "Either vertexShaderSource or fragmentShaderSource " +
                "must be specified");
        }
        
        int shaderProgram;
        int vertexShader = 0;
        int fragmentShader = 0;
        int[] success = new int[1];
        int[] infoLogLength = new int[1];

        if (vertexShaderSource != null) {
            vertexShader = compileShader(gl, vertexShaderSource, true);
            if (vertexShader == 0) {
                return 0;
            }
        }
        
        if (fragmentShaderSource != null) {
            fragmentShader = compileShader(gl, fragmentShaderSource, false);
            if (fragmentShader == 0) {
                if (vertexShader != 0) {
                    gl.glDeleteObjectARB(vertexShader);
                }
                return 0;
            }
        }

        // create the program object and attach it to the shader
        shaderProgram = gl.glCreateProgramObjectARB();
        if (vertexShader != 0) {
            gl.glAttachObjectARB(shaderProgram, vertexShader);
            // it is now safe to delete the shader object
            gl.glDeleteObjectARB(vertexShader);
        }
        if (fragmentShader != 0) {
            gl.glAttachObjectARB(shaderProgram, fragmentShader);
            // it is now safe to delete the shader object
            gl.glDeleteObjectARB(fragmentShader);
        }

        // link the program
        gl.glLinkProgramARB(shaderProgram);
        gl.glGetObjectParameterivARB(shaderProgram,
                                     GL_OBJECT_LINK_STATUS_ARB,
                                     success, 0);

        // print the linker messages, if necessary
        gl.glGetObjectParameterivARB(shaderProgram,
                                     GL_OBJECT_INFO_LOG_LENGTH_ARB,
                                     infoLogLength, 0);
        if (infoLogLength[0] > 1) {
            int len = infoLogLength[0];
            byte[] infoLog = new byte[len];
            gl.glGetInfoLogARB(shaderProgram, len, null, 0, infoLog, 0);
            System.err.println("Linker message: " +
                               new String(infoLog));
        }

        if (success[0] == 0) {
            gl.glDeleteObjectARB(shaderProgram);
            return 0;
        }

        return shaderProgram;
    }
    
    /**
     * Compiles the given shader program.  If successful, this function returns
     * a handle to the newly created shader object; otherwise returns 0.
     * 
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    private static int compileShader(GL gl, String shaderSource, boolean vertex)
        throws GLException
    {
        int kind = vertex ? GL_VERTEX_SHADER_ARB : GL_FRAGMENT_SHADER_ARB;
        int shader;
        int[] success = new int[1];
        int[] infoLogLength = new int[1];

        // create the shader object and compile the shader source code
        shader = gl.glCreateShaderObjectARB(kind);
        gl.glShaderSourceARB(shader, 1, new String[] { shaderSource }, new int[] { -1 }, 0);
        gl.glCompileShaderARB(shader);
        gl.glGetObjectParameterivARB(shader,
                                     GL_OBJECT_COMPILE_STATUS_ARB,
                                     success, 0);

        // print the compiler messages, if necessary
        gl.glGetObjectParameterivARB(shader,
                                     GL_OBJECT_INFO_LOG_LENGTH_ARB,
                                     infoLogLength, 0);
        if (infoLogLength[0] > 1) {
            int len = infoLogLength[0];
            byte[] infoLog = new byte[len];
            gl.glGetInfoLogARB(shader, len, null, 0, infoLog, 0);
            System.err.println(shaderSource);
            System.err.println((vertex ? "Vertex" : "Fragment") +
                               " compile message: " +
                               new String(infoLog));
        }

        if (success[0] == 0) {
            gl.glDeleteObjectARB(shader);
            return 0;
        }
        
        return shader;
    }
    
    /**
     * Returns the underlying OpenGL program object handle for this fragment
     * shader. Most applications will not need to access this, since it is
     * handled automatically by the enable() and dispose() methods.
     * 
     * @return the OpenGL program object handle for this fragment shader
     */
    public int getProgramObject() {
        return id;
    }
    
    /**
     * Enables this shader program in the current GL context's state.
     * 
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void enable() throws GLException {
        GL gl = GLU.getCurrentGL();
        gl.glUseProgramObjectARB(id);
    }
    
    /**
     * Disables this shader program in the current GL context's state.
     * 
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void disable() throws GLException {
        GL gl = GLU.getCurrentGL();
        gl.glUseProgramObjectARB(0);
    }
    
    /**
     * Disposes the native resources used by this program object.
     *
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void dispose() throws GLException {
        GL gl = GLU.getCurrentGL();
        gl.glDeleteObjectARB(id);
        id = 0;
    }

    /**
     * Sets the uniform variable of the given name with the provided
     * integer value.
     *
     * @param name the name of the uniform variable to be set
     * @param i0 the first uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, int i0)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform1iARB(loc, i0);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * integer values.
     *
     * @param name the name of the uniform variable to be set
     * @param i0 the first uniform parameter
     * @param i1 the second uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, int i0, int i1)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform2iARB(loc, i0, i1);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * integer values.
     *
     * @param name the name of the uniform variable to be set
     * @param i0 the first uniform parameter
     * @param i1 the second uniform parameter
     * @param i2 the third uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, int i0, int i1, int i2)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform3iARB(loc, i0, i1, i2);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * integer values.
     *
     * @param name the name of the uniform variable to be set
     * @param i0 the first uniform parameter
     * @param i1 the second uniform parameter
     * @param i2 the third uniform parameter
     * @param i3 the fourth uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, int i0, int i1, int i2, int i3)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform4iARB(loc, i0, i1, i2, i3);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * float value.
     *
     * @param name the name of the uniform variable to be set
     * @param f0 the first uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, float f0)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform1fARB(loc, f0);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * float values.
     *
     * @param name the name of the uniform variable to be set
     * @param f0 the first uniform parameter
     * @param f1 the second uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, float f0, float f1)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform2fARB(loc, f0, f1);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * float values.
     *
     * @param name the name of the uniform variable to be set
     * @param f0 the first uniform parameter
     * @param f1 the second uniform parameter
     * @param f2 the third uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, float f0, float f1, float f2)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform3fARB(loc, f0, f1, f2);
    }
    
    /**
     * Sets the uniform variable of the given name with the provided
     * float values.
     *
     * @param name the name of the uniform variable to be set
     * @param f0 the first uniform parameter
     * @param f1 the second uniform parameter
     * @param f2 the third uniform parameter
     * @param f3 the fourth uniform parameter
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstant(String name, float f0, float f1, float f2, float f3)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform4fARB(loc, f0, f1, f2, f3);
    }
    
    /**
     * Sets the uniform array variable of the given name with the provided
     * int array values.
     *
     * @param name the name of the uniform variable to be set
     * @param buf the array values to be set
     * @param off the offset into the vals array
     * @param count the number of ivec4 elements in the array
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstants(String name, IntBuffer buf, int off, int count)
        throws GLException
    {
        // TODO: remove off param in favor of IntBuffer.position()
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform4ivARB(loc, count, buf);
    }

    /**
     * Sets the uniform array variable of the given name with the provided
     * float array values.
     *
     * @param name the name of the uniform variable to be set
     * @param buf the array values to be set
     * @param count the number of vec4 elements in the array
     * @param off the offset into the vals array
     * @throws GLException if no OpenGL context was current or if any
     * OpenGL-related errors occurred
     */
    public void setConstants(String name, FloatBuffer buf, int off, int count)
        throws GLException
    {
        GL gl = GLU.getCurrentGL();
        int loc = gl.glGetUniformLocationARB(id, name);
        gl.glUniform4fvARB(loc, count, buf);
    }
}
