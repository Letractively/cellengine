/*
 * Copyright 2008 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */

package com.sun.scenario.effect.compiler.parser;

import com.sun.scenario.effect.compiler.JSLParser;
import com.sun.scenario.effect.compiler.model.Type;
import com.sun.scenario.effect.compiler.model.UnaryOpType;
import com.sun.scenario.effect.compiler.tree.LiteralExpr;
import com.sun.scenario.effect.compiler.tree.UnaryExpr;
import com.sun.scenario.effect.compiler.tree.VariableExpr;
import org.antlr.runtime.RecognitionException;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class UnaryExprTest extends PrimaryExprTest {

    private String primary;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        this.primary = primary();
    }

    @Test
    public void negated() throws Exception {
        UnaryExpr tree = parseTreeFor("!true");
        assertEquals(tree.getOp(), UnaryOpType.NOT);
        assertEquals(((LiteralExpr)tree.getExpr()).getValue(), Boolean.TRUE);
    }

    @Test
    public void positive() throws Exception {
        UnaryExpr tree = parseTreeFor("+72.4");
        assertEquals(tree.getOp(), UnaryOpType.PLUS);
        assertEquals(((LiteralExpr)tree.getExpr()).getValue(), new Float(72.4));
    }

    @Test
    public void negative() throws Exception {
        UnaryExpr tree = parseTreeFor("-72.4");
        assertEquals(tree.getOp(), UnaryOpType.MINUS);
        assertEquals(((LiteralExpr)tree.getExpr()).getValue(), new Float(72.4));
    }

    @Test
    public void preIncrement() throws Exception {
        UnaryExpr tree = parseTreeFor("++foo");
        assertEquals(tree.getOp(), UnaryOpType.INC);
        assertEquals(((VariableExpr)tree.getExpr()).getVariable().getName(), "foo");
    }

    @Test
    public void preDecrement() throws Exception {
        UnaryExpr tree = parseTreeFor("--foo");
        assertEquals(tree.getOp(), UnaryOpType.DEC);
        assertEquals(((VariableExpr)tree.getExpr()).getVariable().getName(), "foo");
    }
    
    @Test
    public void postIncrement() throws Exception {
        UnaryExpr tree = parseTreeFor("foo++");
        assertEquals(tree.getOp(), UnaryOpType.INC);
        assertEquals(((VariableExpr)tree.getExpr()).getVariable().getName(), "foo");
    }

    @Test
    public void postDecrement() throws Exception {
        UnaryExpr tree = parseTreeFor("foo--");
        assertEquals(tree.getOp(), UnaryOpType.DEC);
        assertEquals(((VariableExpr)tree.getExpr()).getVariable().getName(), "foo");
    }

    @Test(expected = RecognitionException.class)
    public void notAUnaryExpression() throws Exception {
        parseTreeFor("^" + primary);
    }

    private UnaryExpr parseTreeFor(String text) throws RecognitionException {
        JSLParser parser = parserOver(text);
        parser.getSymbolTable().declareVariable("foo", Type.INT, null);
        parser.getSymbolTable().declareVariable("vec", Type.INT3, null);
        return (UnaryExpr)parser.unary_expression();
    }

    protected String unary() {
        return "(-" + primary() + ")";
    }
}
